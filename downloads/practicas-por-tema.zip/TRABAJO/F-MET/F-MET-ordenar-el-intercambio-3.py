print(total)
for valor in [1, 2, 3]:
    total += valor
total = 0
