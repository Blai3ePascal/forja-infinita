print(resultado)
resultado = valorar(precio)
precio = 3
def valorar(coste):
    return coste * 2
