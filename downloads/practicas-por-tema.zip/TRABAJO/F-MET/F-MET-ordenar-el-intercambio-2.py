print(saldo)
if precio <= saldo:
    saldo = saldo - precio
precio = 2
saldo = 6
