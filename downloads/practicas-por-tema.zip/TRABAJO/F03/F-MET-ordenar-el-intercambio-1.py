print(saldo)
saldo = saldo - precio
precio = 1
saldo = 5
