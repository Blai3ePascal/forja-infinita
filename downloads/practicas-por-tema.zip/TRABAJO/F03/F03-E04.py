datos = [4, 4, 2]

# Completa el encargo: Usa [-8, -3, -5] y comprueba que el resultado conserva su
# signo.

# Calcula el resultado a partir de los datos y muéstralo.
