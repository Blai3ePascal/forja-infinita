datos = [2, 4, 7, 9, 12]

buscado = 12

posicion = -1

# Completa el encargo: El caso de comprobación busca 12 en [2, 4, 7, 9, 12].
# Debe devolver la posición 4. Comprueba que el intervalo se reduce en cada
# paso; una actualización que no avance puede agotar el límite de ejecución.

# Calcula el resultado a partir de los datos y muéstralo.
