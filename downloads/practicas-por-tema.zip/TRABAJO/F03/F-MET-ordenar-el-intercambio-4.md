### El encargo

El archivo de la forja necesita localizar y ordenar información con un procedimiento preciso.

Define la función antes de llamarla, prepara el argumento y conserva el valor devuelto antes de mostrarlo. Ordena los bloques con Subir y Bajar; después se ejecuta Python real.

### Requisitos de aprendizaje

- Mostrar valores obtenidos de los datos; no escribir todos los resultados como literales.

### Resultado de referencia

```text
6
```

### Tu margen de decisión

Puedes cambiar nombres y organizar el código de otra forma, salvo firmas, tablas, archivos o técnicas exigidos arriba. La propuesta del cuaderno es una solución posible. En «Probar cambios» puedes explorar otros datos sin alterar tu borrador ni ganar recompensas.
