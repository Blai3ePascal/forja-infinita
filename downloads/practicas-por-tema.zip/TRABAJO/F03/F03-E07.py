datos = [2, 4, 7, 9]
buscado = 7
posicion = -1
# Completa aquí: Resuelve el paso pendiente de Búsqueda lineal con posición.
# Consulta los datos y requisitos del encargo.
...
print(posicion)
