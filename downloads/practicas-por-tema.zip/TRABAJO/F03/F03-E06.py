datos = [2, 4, 7, 9]

buscado = 9

posicion = -1

# Completa el encargo: El caso de comprobación busca 9 en [2, 4, 7, 9]. Debe
# devolver la posición 3: así se comprueba que también se visita el último
# elemento.

# Calcula el resultado a partir de los datos y muéstralo.
