datos = [2, 4, 7, 9]
buscado = 9
posicion = -1
for i in range(len(datos) - 1):
    if datos[i] == buscado:
        posicion = i
        break
print(posicion)
