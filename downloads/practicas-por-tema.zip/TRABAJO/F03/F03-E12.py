datos = [2, 4, 7, 9, 12]

buscado = 9

posicion = -1

# Completa el encargo: Busca el valor 6, ausente, y conserva los límites
# correctos.

# Calcula el resultado a partir de los datos y muéstralo.
