datos = [2, 4, 7, 9, 12]
buscado = 9
izquierda, derecha = 0, len(datos) - 1
posicion = -1
while izquierda <= derecha:
    medio = (izquierda + derecha) // 2
    if datos[medio] == buscado:
        posicion = medio
        break
    if datos[medio] < buscado:
        # Completa aquí: Resuelve el paso pendiente de Búsqueda binaria y datos
        # ordenados. Consulta los datos y requisitos del encargo.
        ...
    else:
        derecha = medio - 1
print(posicion)
