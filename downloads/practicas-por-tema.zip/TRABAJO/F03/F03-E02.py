datos = [-4, -4, -6]

mayor = 0

# Completa el encargo: El caso de comprobación usa tres valores negativos y un
# empate: -4, -4 y -6. El máximo debe ser -4. Iniciar el máximo en cero oculta
# el problema con datos positivos.

# Calcula el resultado a partir de los datos y muéstralo.
