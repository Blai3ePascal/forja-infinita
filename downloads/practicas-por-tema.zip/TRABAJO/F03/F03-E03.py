datos = [4, 4, 2]
TODO
for valor in datos[1:]:
    if valor > mayor:
        mayor = valor
print(mayor)
