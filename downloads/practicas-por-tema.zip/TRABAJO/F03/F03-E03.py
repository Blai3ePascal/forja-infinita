datos = [4, 4, 2]
# Completa aquí: Resuelve el paso pendiente de Mayor de tres con empate.
# Consulta los datos y requisitos del encargo.
...
for valor in datos[1:]:
    if valor > mayor:
        mayor = valor
print(mayor)
