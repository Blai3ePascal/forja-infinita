datos = [2, 4, 7, 9]

buscado = 7

posicion = -1

# Completa el encargo: Busca 9 y después 6. Entrega las dos predicciones antes
# de ejecutar.

# Calcula el resultado a partir de los datos y muéstralo.
