texto = "ñ"
print(len(texto))
# Completa aquí: Resuelve el paso pendiente de Un carácter y su codificación.
# Consulta los datos y requisitos del encargo.
...
print(2**8)
