texto = "ñ"
print(len(texto))
print(TODO)
print(2**8)
