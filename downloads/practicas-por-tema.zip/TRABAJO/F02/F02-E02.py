# Investiga el fallo: El mismo número en tres bases. Lee el encargo antes de
# ejecutar.
numero = 13
print(numero)
print(format(numero, "X"))
print(format(numero, "X"))
