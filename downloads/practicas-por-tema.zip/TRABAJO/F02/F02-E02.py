numero = 13
print(numero)
print(format(numero, "X"))
print(format(numero, "X"))
