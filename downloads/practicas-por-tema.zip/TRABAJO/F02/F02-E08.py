texto = "ñ"

# Completa el encargo: Compara la longitud de A en texto y UTF-8, manteniendo el
# cálculo de combinaciones.

# Calcula el resultado a partir de los datos y muéstralo.
