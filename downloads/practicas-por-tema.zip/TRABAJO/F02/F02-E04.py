numero = 13

# Completa el encargo: Representa 27 en decimal, binario y hexadecimal.

# Calcula el resultado a partir de los datos y muéstralo.
