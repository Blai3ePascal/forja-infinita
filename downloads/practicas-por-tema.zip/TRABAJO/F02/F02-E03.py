numero = 13
print(numero)
print(TODO)
print(format(numero, "X"))
