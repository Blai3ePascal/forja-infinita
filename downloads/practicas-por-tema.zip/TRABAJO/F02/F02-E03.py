numero = 13
print(numero)
# Completa aquí: Resuelve el paso pendiente de El mismo número en tres bases.
# Consulta los datos y requisitos del encargo.
...
print(format(numero, "X"))
