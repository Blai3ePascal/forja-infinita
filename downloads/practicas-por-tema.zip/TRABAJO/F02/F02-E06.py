# Investiga el fallo: Un carácter y su codificación. Lee el encargo antes de
# ejecutar.
texto = "ñ"
print(len(texto))
print(len(texto))
print(2**8)
