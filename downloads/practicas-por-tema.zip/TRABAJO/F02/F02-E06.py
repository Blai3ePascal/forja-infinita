texto = "ñ"
print(len(texto))
print(len(texto))
print(2**8)
