from PIL import Image
im = Image.open("insignia.png")
# Completa la transformación o consulta.
