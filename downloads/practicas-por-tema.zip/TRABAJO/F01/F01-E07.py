print("Sala", 4)
TODO
print("Preparados")
