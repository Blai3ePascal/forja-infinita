print("Sala", 4)
# Completa aquí: Resuelve el paso pendiente de Mensajes separados. Consulta los
# datos y requisitos del encargo.
...
print("Preparados")
