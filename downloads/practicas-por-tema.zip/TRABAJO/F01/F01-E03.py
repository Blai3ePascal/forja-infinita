print("Marcador")
# Completa aquí: Resuelve el paso pendiente de Un marcador en pantalla. Consulta
# los datos y requisitos del encargo.
...
print("2 + 3")
