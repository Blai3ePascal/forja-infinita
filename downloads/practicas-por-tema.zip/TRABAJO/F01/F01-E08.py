# Completa el encargo: Muestra Sala 8 y Turno 3.

# Calcula el resultado a partir de los datos y muéstralo.
