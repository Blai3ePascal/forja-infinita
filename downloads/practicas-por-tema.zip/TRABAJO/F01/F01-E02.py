# Investiga el fallo: Un marcador en pantalla. Lee el encargo antes de ejecutar.
print("Marcador")
print("2 + 3")
print("2 + 3")
