print("Sala", 4)
print(Turno, 2)
print("Preparados")
