# Investiga el fallo: Mensajes separados. Lee el encargo antes de ejecutar.
print("Sala", 4)
print(Turno, 2)
print("Preparados")
