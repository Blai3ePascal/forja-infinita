# Completa el encargo: Cambia el marcador a 4 + 6 y conserva una línea con la
# expresión escrita.

# Calcula el resultado a partir de los datos y muéstralo.
