SELECT tipo,
       COUNT(*) AS cantidad
FROM cartas
GROUP BY tipo
HAVING COUNT(*)>=2
ORDER BY tipo;
