SELECT AVG(coste) AS media
FROM cartas;
