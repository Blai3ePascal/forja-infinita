import sqlite3
from contextlib import closing

with closing(sqlite3.connect(":memory:")) as db:
    db.execute("CREATE TABLE equipo(id INTEGER PRIMARY KEY, nombre TEXT NOT NULL)")
    db.execute("INSERT INTO equipo VALUES(?,?)", (1, "Azul"))
    print(db.execute("SELECT id,nombre FROM equipo ORDER BY id").fetchall())
