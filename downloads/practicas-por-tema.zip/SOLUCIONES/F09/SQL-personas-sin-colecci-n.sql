SELECT p.nombre
FROM personas p
LEFT JOIN coleccion k ON p.id=k.persona_id
WHERE k.carta_id IS NULL
ORDER BY p.id;
