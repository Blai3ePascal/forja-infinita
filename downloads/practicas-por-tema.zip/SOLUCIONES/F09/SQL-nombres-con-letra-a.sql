SELECT nombre
FROM cartas
WHERE nombre LIKE '%a%'
ORDER BY id;
