SELECT DISTINCT tipo
FROM cartas
ORDER BY tipo;
