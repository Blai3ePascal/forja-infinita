SELECT p.nombre,
       c.nombre,
       k.copias
FROM coleccion k
JOIN personas p ON p.id=k.persona_id
JOIN cartas c ON c.id=k.carta_id
ORDER BY p.id,
         c.id;
