SELECT nombre
FROM cartas
WHERE coste>
    (SELECT AVG(coste)
     FROM cartas)
ORDER BY id;
