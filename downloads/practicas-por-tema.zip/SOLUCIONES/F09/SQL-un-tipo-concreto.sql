SELECT nombre
FROM cartas
WHERE tipo='Luz'
ORDER BY id;
