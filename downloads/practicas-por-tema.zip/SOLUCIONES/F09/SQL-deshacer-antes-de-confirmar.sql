BEGIN;

UPDATE cartas
SET coste=99
WHERE id=1;

ROLLBACK;
