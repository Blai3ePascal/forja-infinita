SELECT tipo,
       COUNT(*) AS cantidad
FROM cartas
GROUP BY tipo
ORDER BY tipo;
