SELECT MAX(coste) AS mayor
FROM cartas;
