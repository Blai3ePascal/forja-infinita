SELECT nombre,
       coste
FROM cartas
ORDER BY coste DESC,
         id;
