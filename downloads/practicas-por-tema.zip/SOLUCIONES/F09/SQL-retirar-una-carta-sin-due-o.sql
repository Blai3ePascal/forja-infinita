DELETE
FROM cartas
WHERE id=4;
