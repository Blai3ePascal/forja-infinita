SELECT p.nombre,
       SUM(k.copias) AS total
FROM personas p
JOIN coleccion k ON p.id=k.persona_id
GROUP BY p.id,
         p.nombre
ORDER BY total DESC,
         p.id
LIMIT 1;
