SELECT c.nombre
FROM cartas c
LEFT JOIN coleccion k ON c.id=k.carta_id
WHERE k.carta_id IS NULL
ORDER BY c.id;
