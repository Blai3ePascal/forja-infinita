SELECT nombre,
       coste
FROM cartas
WHERE coste>=5
ORDER BY id;
