SELECT nombre
FROM cartas
ORDER BY id;
