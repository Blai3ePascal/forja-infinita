INSERT INTO cartas
VALUES(5,'Eco','Aire',4);
