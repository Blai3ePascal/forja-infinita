SELECT p.nombre,
       COUNT(k.carta_id) AS distintas
FROM personas p
LEFT JOIN coleccion k ON p.id=k.persona_id
GROUP BY p.id,
         p.nombre
ORDER BY p.id;
