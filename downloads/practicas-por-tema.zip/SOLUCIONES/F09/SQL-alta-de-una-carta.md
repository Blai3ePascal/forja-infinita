### El encargo

Consulta el archivo de la forja: devuelve solo la información que pide el encargo.

Inserta la carta id 5, nombre Eco, tipo Aire y coste 4.

### Datos de partida

- `personas(id, nombre)`: (1, Luna), (2, Mar), (3, Sol).
- `cartas(id, nombre, tipo, coste)`: (1, Faro, Luz, 2), (2, Marea, Agua, 5), (3, Brasa, Fuego, 3), (4, Aurora, Luz, 7).
- `coleccion(persona_id, carta_id, copias)`: (1,1,2), (1,2,1), (2,3,3).
- Claves primarias: `id` en personas/cartas y la pareja `(persona_id,carta_id)` en coleccion. Ambos id de coleccion son claves foráneas.

### Requisitos de aprendizaje

- Consultar o modificar las tablas preparadas. La solución se comprueba con distintos datos.

### Casos de referencia

- Estado final: `[[1, "Faro", "Luz", 2], [2, "Marea", "Agua", 5], [3, "Brasa", "Fuego", 3], [4, "Aurora", "Luz", 7], [5, "Eco", "Aire", 4]]`

### Tu margen de decisión

Puedes cambiar nombres y organizar el código de otra forma, salvo firmas, tablas, archivos o técnicas exigidos arriba. La propuesta del cuaderno es una solución posible. En «Probar cambios» puedes explorar otros datos sin alterar tu borrador ni ganar recompensas.


Inserta la carta id 5, nombre Eco, tipo Aire y coste 4.

### Leer la propuesta

- `INSERT INTO cartas VALUES(5,'Eco','Aire',4);`: Conserva o actualiza este dato antes de la siguiente operación. Puedes consultar cada palabra en el glosario.

### Prueba otra decisión

En Probar cambios cambia un dato o un tamaño y compara la salida. Vuelve al objetivo para comprobar los casos de la misión. Si aparecen dos bucles, identifica qué recorre cada uno; si aparece una dirección, distingue el puntero de su destino.

El motor compara valores y orden cuando se ha pedido, sin exigir el mismo nombre de alias ni la misma consulta. COUNT(*) cuenta filas; COUNT(carta_id) omite los NULL de las personas sin pareja. WHERE se aplica a filas y HAVING a grupos.