import sqlite3
from contextlib import closing
from pathlib import Path

ruta = Path("equipos.sqlite")
# La base pertenece exclusivamente a esta actividad; reconstrucción reproducible.
if ruta.exists():
    ruta.unlink()
with closing(sqlite3.connect(ruta)) as db:
    db.execute("PRAGMA foreign_keys=ON")
    with db:
        db.execute("CREATE TABLE sala(id INTEGER PRIMARY KEY)")
        db.execute(
            "CREATE TABLE equipo(id INTEGER PRIMARY KEY,nombre TEXT NOT NULL,sala_id INTEGER NOT NULL REFERENCES sala(id))"
        )
        db.execute("INSERT INTO sala VALUES(?)", (4,))
        db.execute("INSERT INTO equipo VALUES(?,?,?)", (1, "Azul", 4))
with closing(sqlite3.connect(ruta)) as db:
    db.execute("PRAGMA foreign_keys=ON")
    print(
        "Reabierta:",
        db.execute("SELECT id,nombre,sala_id FROM equipo ORDER BY id").fetchall(),
    )
    try:
        with db:
            db.execute("INSERT INTO equipo VALUES(?,?,?)", (2, "Rojo", 99))
    except sqlite3.IntegrityError:
        print("Referencia inexistente rechazada")
    filas = db.execute("SELECT id,nombre,sala_id FROM equipo ORDER BY id").fetchall()
    assert filas == [(1, "Azul", 4)]
    print("Tras rechazo:", filas)
