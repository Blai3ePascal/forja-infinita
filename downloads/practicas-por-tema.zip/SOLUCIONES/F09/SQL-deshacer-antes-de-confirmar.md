Inicia una transacción, cambia temporalmente el coste de la carta 1 a 99 y revierte. La comprobación final debe encontrar el coste original.

### Datos de partida

- `personas(id, nombre)`: (1, Luna), (2, Mar), (3, Sol).
- `cartas(id, nombre, tipo, coste)`: (1, Faro, Luz, 2), (2, Marea, Agua, 5), (3, Brasa, Fuego, 3), (4, Aurora, Luz, 7).
- `coleccion(persona_id, carta_id, copias)`: (1,1,2), (1,2,1), (2,3,3).
- Claves primarias: `id` en personas/cartas y la pareja `(persona_id,carta_id)` en coleccion. Ambos id de coleccion son claves foráneas.

Inicia una transacción, cambia temporalmente el coste de la carta 1 a 99 y revierte. La comprobación final debe encontrar el coste original.

### Leer la propuesta

- `BEGIN; UPDATE cartas SET coste=99 WHERE id=1; ROLLBACK;`: Conserva o actualiza este dato antes de la siguiente operación. Puedes consultar cada palabra en el glosario.

### Prueba otra decisión

En Probar cambios cambia un dato o un tamaño y compara la salida. Vuelve al objetivo para comprobar los casos de la misión. Si aparecen dos bucles, identifica qué recorre cada uno; si aparece una dirección, distingue el puntero de su destino.

El motor compara valores y orden cuando se ha pedido, sin exigir el mismo nombre de alias ni la misma consulta. COUNT(*) cuenta filas; COUNT(carta_id) omite los NULL de las personas sin pareja. WHERE se aplica a filas y HAVING a grupos.

El motor ejecuta cada sentencia y observa el valor: debe llegar a 99 dentro de la transacción y regresar a 2 al deshacer. Una consulta que deje los datos intactos sin realizar el cambio no cumple el objetivo.