SELECT COUNT(*) AS total
FROM cartas;
