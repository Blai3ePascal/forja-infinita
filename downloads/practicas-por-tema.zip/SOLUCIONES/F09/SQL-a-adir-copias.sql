UPDATE coleccion
SET copias=copias+1
WHERE persona_id=1
  AND carta_id=1;
