import sqlite3

with sqlite3.connect(":memory:") as db:
    db.execute(("CREATE TABLE nota(id INTEGER PRIMARY KEY, " "valor REAL)"))
    db.executescript(
        (
            "INSERT INTO nota VALUES(1,4); INSERT INTO "
            "nota VALUES(2,5); INSERT INTO nota "
            "VALUES(3,8);"
        )
    )
    filas = db.execute(
        ("SELECT id, valor FROM nota WHERE valor < 5 " "ORDER BY id")
    ).fetchall()
    print(filas)
