import sqlite3
from contextlib import closing

with closing(sqlite3.connect(":memory:")) as db:
    db.execute("CREATE TABLE nota(id INTEGER PRIMARY KEY,valor INTEGER)")
    db.executemany("INSERT INTO nota VALUES(?,?)", [(1, 5), (2, 3), (3, 8)])
    db.commit()
    inicial = db.execute("SELECT * FROM nota ORDER BY id").fetchall()
    print("Cambiar:", db.execute("SELECT * FROM nota WHERE id=?", (1,)).fetchall())
    print("Borrar:", db.execute("SELECT * FROM nota WHERE valor<?", (5,)).fetchall())
    db.execute("BEGIN")
    cambiadas = db.execute("UPDATE nota SET valor=valor+? WHERE id=?", (2, 1)).rowcount
    borradas = db.execute("DELETE FROM nota WHERE valor<?", (5,)).rowcount
    print("Afectadas:", cambiadas, borradas)
    print("Temporal:", db.execute("SELECT * FROM nota ORDER BY id").fetchall())
    db.rollback()
    final = db.execute("SELECT * FROM nota ORDER BY id").fetchall()
    print("Tras rollback:", final)
    assert final == inicial
