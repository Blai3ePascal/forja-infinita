SELECT nombre
FROM cartas
WHERE coste BETWEEN 2 AND 5
ORDER BY id;
