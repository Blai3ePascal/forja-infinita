import sqlite3

with sqlite3.connect(":memory:") as db:
    db.executescript(
        (
            "CREATE TABLE sala(id INTEGER PRIMARY KEY, "
            "nombre TEXT); CREATE TABLE equipo(id "
            "INTEGER PRIMARY KEY, sala_id INTEGER);"
        )
    )
    db.executescript(
        (
            "INSERT INTO sala "
            "VALUES(1,'Norte'),(2,'Sur'); INSERT INTO "
            "equipo VALUES(10,2),(20,1);"
        )
    )
    consulta = (
        "SELECT e.id, s.nombre FROM equipo e JOIN "
        "sala s ON e.sala_id = s.id WHERE s.nombre = "
        "'Sur' ORDER BY e.id"
    )
    print(db.execute(consulta).fetchall())
