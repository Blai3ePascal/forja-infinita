SELECT nombre
FROM cartas
WHERE tipo IN ('Luz',
               'Agua')
ORDER BY id;
