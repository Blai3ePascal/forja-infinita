import sqlite3

with sqlite3.connect(":memory:") as db:
    db.execute(("CREATE TABLE entrega(grupo TEXT, puntos " "INTEGER)"))
    db.executescript(
        (
            "INSERT INTO entrega VALUES('A',3); INSERT "
            "INTO entrega VALUES('A',5); INSERT INTO "
            "entrega VALUES('B',4);"
        )
    )
    print(
        db.execute(
            (
                "SELECT grupo, SUM(puntos) FROM entrega "
                "GROUP BY grupo HAVING SUM(puntos) >= 6 "
                "ORDER BY grupo"
            )
        ).fetchall()
    )
