UPDATE cartas
SET coste=6
WHERE id=2;
