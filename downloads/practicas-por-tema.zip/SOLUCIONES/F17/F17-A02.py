from pathlib import Path
from html.parser import HTMLParser

contenido = """<!doctype html><html lang="es"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Registro de una nota</title>
<style>body{background:#f7f0e3;color:#263d43;font:18px/1.5 sans-serif;padding:24px;max-width:45rem}input,button{font:inherit;padding:8px;max-width:100%}label{display:block;font-weight:bold}button{margin-top:16px}</style>
</head><body><h1>Registro de una nota</h1>
<p id="ayuda">Introduce un número entre 0 y 10. Este prototipo muestra la captura; no envía datos.</p>
<form onsubmit="return false;">
<label for="nota">Nota sobre 10</label>
<input id="nota" name="nota" type="number" min="0" max="10" step="0.1" required aria-describedby="ayuda">
<br><button type="submit">Comprobar el intervalo</button>
</form></body></html>"""
Path("formulario.html").write_text(contenido, encoding="utf-8")

class Campos(HTMLParser):
    def __init__(self):
        super().__init__()
        self.etiqueta = None
        self.campo = None
    def handle_starttag(self, tag, attrs):
        datos = dict(attrs)
        if tag == "label":
            self.etiqueta = datos.get("for")
        if tag == "input":
            self.campo = datos

campos = Campos()
campos.feed(contenido)
assert campos.etiqueta == campos.campo["id"]
assert campos.campo["min"] == "0"
assert campos.campo["max"] == "10"
assert campos.campo["aria-describedby"] == "ayuda"
print("Etiqueta asociada: nota")
print("Intervalo declarado: 0 a 10")
print("Archivo: formulario.html")
