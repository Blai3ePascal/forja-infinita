import csv
from io import StringIO
from pathlib import Path

datos = "grupo,nota\nA,8\nA,4\nB,7\nB,12\n"
resumen = {}
descartadas = 0
for fila in csv.DictReader(StringIO(datos)):
    nota = float(fila["nota"])
    if not 0 <= nota <= 10:
        descartadas += 1
        continue
    grupo = fila["grupo"]
    resumen.setdefault(grupo, []).append(nota)
with Path("resumen.csv").open("w", encoding="utf-8", newline="") as archivo:
    salida = csv.writer(archivo, lineterminator="\n")
    salida.writerow(["grupo", "n", "media"])
    for grupo in sorted(resumen):
        valores = resumen[grupo]
        salida.writerow([grupo, len(valores), f"{sum(valores)/len(valores):.2f}"])
print(Path("resumen.csv").read_text(encoding="utf-8"), end="")
print("Descartadas:", descartadas)
print("Datos ficticios. Compara también el tamaño de cada grupo.")
