texto = "8"
nota = float(texto)
print("Aceptada:", 0 <= nota <= 10)
