def leer_nota():
    while True:
        try:
            texto = input("Nota [0..10]: ").strip()
        except EOFError:
            return None
        try:
            nota = float(texto)
        except ValueError:
            print("Escribe un número.")
            continue
        if not 0 <= nota <= 10:
            print("Usa un valor entre 0 y 10.")
            continue
        return nota

nota = leer_nota()
if nota is None:
    print("Sin datos.")
else:
    print(f"Aceptada: {nota:.1f}")
