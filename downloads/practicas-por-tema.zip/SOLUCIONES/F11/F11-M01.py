datos = [4, 1, 4, -2]
referencia = sorted(datos)
print(referencia)
print(datos)
print(len(datos), len(referencia), sum(datos) == sum(referencia))
