def ordenar(datos):
    if len(datos) < 2:
        return datos.copy(), 0
    pivote = datos[0]
    menores, iguales, mayores = [], [pivote], []
    c = 0
    for valor in datos[1:]:
        c += 1
        if valor < pivote:
            menores.append(valor)
        else:
            c += 1
            if valor > pivote:
                mayores.append(valor)
            else:
                iguales.append(valor)
    izq, ci = ordenar(menores)
    der, cd = ordenar(mayores)
    return izq + iguales + der, c + ci + cd

from collections import Counter
casos = [[], [7], [3, 1, 3, -2], [1, 2, 3, 4], [4, 3, 2, 1]]
for caso in casos:
    antes = caso.copy()
    salida, comparaciones = ordenar(caso)
    assert salida == sorted(caso)
    assert Counter(salida) == Counter(caso)
    assert caso == antes
    print(caso, '->', salida, 'comparaciones:', comparaciones)
for n in [4, 8]:
    asc = list(range(n))
    desc = list(reversed(asc))
    print('n:', n, 'ordenado:', ordenar(asc)[1], 'inverso:', ordenar(desc)[1])
