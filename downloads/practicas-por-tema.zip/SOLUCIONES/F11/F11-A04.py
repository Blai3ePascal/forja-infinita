def ordenar(datos):
    def dividir(a):
        if len(a) < 2:
            return a.copy(), 0
        medio = len(a) // 2
        izq, ci = dividir(a[:medio])
        der, cd = dividir(a[medio:])
        salida, i, j, c = [], 0, 0, ci + cd
        while i < len(izq) and j < len(der):
            c += 1
            if izq[i] <= der[j]:
                salida.append(izq[i]); i += 1
            else:
                salida.append(der[j]); j += 1
        salida.extend(izq[i:])
        salida.extend(der[j:])
        return salida, c
    return dividir(datos)

from collections import Counter
casos = [[], [7], [3, 1, 3, -2], [1, 2, 3, 4], [4, 3, 2, 1]]
for caso in casos:
    antes = caso.copy()
    salida, comparaciones = ordenar(caso)
    assert salida == sorted(caso)
    assert Counter(salida) == Counter(caso)
    assert caso == antes
    print(caso, '->', salida, 'comparaciones:', comparaciones)
for n in [4, 8]:
    asc = list(range(n))
    desc = list(reversed(asc))
    print('n:', n, 'ordenado:', ordenar(asc)[1], 'inverso:', ordenar(desc)[1])
