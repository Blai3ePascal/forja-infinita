import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

fig, ax = plt.subplots(figsize=(6, 4))
ax.plot([1, 2, 3], [10, 14, 18], marker="o")
ax.set(xlabel="Dia", ylabel="Ventas (unidades)", title="Ventas observadas por dia")
fig.tight_layout()
fig.savefig("referencia_linea.png", dpi=120)
plt.close(fig)
print("Archivo: referencia_linea.png; puntos: 3")
