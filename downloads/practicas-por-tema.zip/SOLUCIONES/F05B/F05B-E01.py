import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

fig, ax = plt.subplots()
ax.bar(["A", "B"], [12, 8])
ax.set(xlabel="Grupo", ylabel="Entregas", title="Entregas por grupo")
fig.savefig("entregas.png")
plt.close(fig)
print("Total:", 12 + 8)
