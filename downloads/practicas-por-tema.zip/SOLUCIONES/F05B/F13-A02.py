import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

minutos = np.array([10, 20, 30, 40, 50], dtype=float)
puntos = np.array([2, 4, 3, 7, 6], dtype=float)
assert minutos.shape == puntos.shape
fig, ax = plt.subplots(figsize=(6, 4))
ax.scatter(minutos, puntos, color="#176b6d")
ax.annotate("Observacion 3", (30, 3), xytext=(31, 2.3))
ax.set(
    xlabel="Estudio (min)",
    ylabel="Puntuacion (puntos)",
    title="Cinco parejas observadas",
)
fig.tight_layout()
fig.savefig("dispersion.png", dpi=120)
plt.close(fig)
r = float(np.corrcoef(minutos, puntos)[0, 1])
print("Punto 3:", int(minutos[2]), int(puntos[2]))
print("Correlacion:", f"{r:.6f}")
print("Interpretacion: asociacion positiva; no prueba causalidad")
