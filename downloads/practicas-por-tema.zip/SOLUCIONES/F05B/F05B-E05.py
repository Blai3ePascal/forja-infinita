observaciones = [(3, 18), (1, 10), (2, 14)]
ordenadas = sorted(observaciones)
dias = [fila[0] for fila in ordenadas]
ventas = [fila[1] for fila in ordenadas]
print(dias)
print(ventas)
