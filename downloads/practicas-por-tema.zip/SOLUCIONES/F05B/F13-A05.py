import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

x = np.array([1.0, 2.0, 3.0, 4.0])
y = np.array([2.0, 3.0, 5.0, 4.0])
a, b = np.polyfit(x, y, 1)
estimada = a * x + b
residuos = y - estimada
sse = float(np.sum(residuos**2))
sst = float(np.sum((y - y.mean()) ** 2))
r2 = 1 - sse / sst if sst > 0 else None
fig, ax = plt.subplots(figsize=(6, 4))
ax.scatter(x, y, label="Observado")
ax.plot(x, estimada, color="#b54f36", label="Ajuste en muestra")
ax.set(
    xlabel="Tiempo (h)",
    ylabel="Medida (u)",
    title="Recta y observaciones: cuatro datos",
)
ax.legend()
fig.tight_layout()
fig.savefig("regresion.png", dpi=120)
plt.close(fig)
print("Pendiente e intercepto:", f"{a:.6f}", f"{b:.6f}")
print("Residuos:", [round(float(r), 6) for r in residuos])
print("R2 muestra:", f"{r2:.6f}")
assert np.allclose(estimada, [2.3, 3.1, 3.9, 4.7])
assert abs(float(residuos.sum())) < 1e-10
