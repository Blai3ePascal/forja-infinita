import sqlite3
from contextlib import closing
with closing(sqlite3.connect(':memory:')) as db:
    db.execute('CREATE TABLE equipo(id INTEGER PRIMARY KEY,nombre TEXT NOT NULL)')
    db.executemany('INSERT INTO equipo VALUES(?,?)', [(1,'Azul'),(2,'Verde')])
    db.execute('ALTER TABLE equipo ADD COLUMN activo INTEGER NOT NULL DEFAULT 1')
    db.execute('UPDATE equipo SET activo=? WHERE id=?', (0,2))
    db.execute('CREATE TABLE ensayo(id INTEGER PRIMARY KEY)')
    antes = db.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name").fetchall()
    print('Tablas antes:', antes)
    db.execute('DROP TABLE ensayo')
    columnas = [fila[1] for fila in db.execute('PRAGMA table_info(equipo)')]
    filas = db.execute('SELECT id,nombre,activo FROM equipo ORDER BY id').fetchall()
    despues = db.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name").fetchall()
    print('Columnas:', columnas)
    print('Filas:', filas)
    print('Tablas despues:', despues)
    assert columnas == ['id','nombre','activo']
    assert filas == [(1,'Azul',1),(2,'Verde',0)]
    assert despues == [('equipo',)]
