import sqlite3
from contextlib import closing
with closing(sqlite3.connect(':memory:')) as db:
    db.execute('CREATE TABLE a(nombre TEXT NOT NULL)')
    db.execute('CREATE TABLE b(nombre TEXT NOT NULL)')
    db.executemany('INSERT INTO a VALUES(?)', [('Azul',),('Azul',),('Verde',)])
    db.executemany('INSERT INTO b VALUES(?)', [('Verde',),('Rojo',)])
    esperados = {'UNION':[('Azul',),('Rojo',),('Verde',)], 'INTERSECT':[('Verde',)], 'EXCEPT':[('Azul',)], 'UNION ALL':[('Azul',),('Azul',),('Rojo',),('Verde',),('Verde',)]}
    for operacion in ['UNION','INTERSECT','EXCEPT','UNION ALL']:
        # La operación procede de esta lista fija, no de entrada del usuario.
        sql = 'SELECT nombre FROM a ' + operacion + ' SELECT nombre FROM b ORDER BY nombre'
        filas = db.execute(sql).fetchall()
        print(operacion, filas)
        assert filas == esperados[operacion]
    print('b menos a:', db.execute('SELECT nombre FROM b EXCEPT SELECT nombre FROM a ORDER BY nombre').fetchall())
