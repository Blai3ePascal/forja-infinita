def valorar(coste):
    return coste * 2
