def tarifa(edad):
    if edad < 18:
        return 5
    return 10

for edad in [17, 18]:
    print(edad, tarifa(edad))
