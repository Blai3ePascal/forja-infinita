class Marcador:
    def __init__(self, nombre):
        self.nombre = nombre
        self.puntos = 0
    def sumar(self, cantidad):
        self.puntos += cantidad
equipo = Marcador("Azul")
equipo.sumar(3)
equipo.sumar(2)
print(equipo.nombre, equipo.puntos)
