def resumen(*puntos, **datos):
    return datos["nombre"], sum(puntos)


print(resumen(4, 1, 2, nombre="Verde"))
