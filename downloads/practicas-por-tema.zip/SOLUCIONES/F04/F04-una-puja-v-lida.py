def aceptar(texto):
    try:
        valor = int(texto)
        return valor if valor >= 0 else None
    except ValueError:
        return None
