notas = [4, 8, 6]
total = 0
for nota in notas:
    total += nota
print(total / len(notas))
print(notas[0])
