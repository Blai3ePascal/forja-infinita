from datetime import date
fecha = date(2026, 10, 21)
nota = 7.5
print(fecha.strftime("%d/%m/%Y"))
print(f"Nota: {nota:.2f}")
