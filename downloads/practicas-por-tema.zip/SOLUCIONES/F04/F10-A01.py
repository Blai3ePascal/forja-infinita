def invertir(datos):
    resultado = datos.copy()
    izquierda, derecha = 0, len(resultado) - 1
    while izquierda < derecha:
        resultado[izquierda], resultado[derecha] = (
            resultado[derecha],
            resultado[izquierda],
        )
        izquierda += 1
        derecha -= 1
    return resultado


datos = [4, 7, 2, 9]
print(invertir(datos))
print(datos)
for caso in [[], [5], [1, 1, 2], [-2, 0, 8]]:
    antes = caso.copy()
    assert invertir(caso) == list(reversed(caso))
    assert invertir(invertir(caso)) == caso
    assert caso == antes
print("Casos comprobados: 4")
