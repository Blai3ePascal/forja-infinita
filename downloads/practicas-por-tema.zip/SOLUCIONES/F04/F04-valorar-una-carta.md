Devuelve el doble del coste recibido. El archivo conserva una función; el motor la prueba con tres costes.

### Casos de comprobación

| Caso | Entrada | Resultado |
|---|---|---|
| Coste cero | `[0]` | `0` |
| Carta intermedia | `[3]` | `6` |
| Carta de mayor coste | `[8]` | `16` |

Devuelve el doble del coste recibido. El archivo conserva una función; el motor la prueba con tres costes.

### Casos de comprobación

| Caso | Entrada | Resultado |
|---|---|---|
| Coste cero | `[0]` | `0` |
| Carta intermedia | `[3]` | `6` |
| Carta de mayor coste | `[8]` | `16` |


### Leer la propuesta

- `def valorar(coste):`: La cabecera define el nombre y los parámetros que recibirá la función.
- `return coste * 2`: Entrega este valor al código que llamó a la función; no equivale a mostrarlo en pantalla.

### Prueba otra decisión

En Probar cambios cambia un dato o un tamaño y compara la salida. Vuelve al objetivo para comprobar los casos de la misión. Si aparecen dos bucles, identifica qué recorre cada uno; si aparece una dirección, distingue el puntero de su destino.