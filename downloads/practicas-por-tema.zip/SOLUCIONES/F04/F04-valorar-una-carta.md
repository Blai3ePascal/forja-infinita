### El encargo

Construye las herramientas que harán funcionar la forja: datos, decisiones y funciones.

Devuelve el doble del coste recibido. El archivo conserva una función; el motor la prueba con tres costes.

### Casos de comprobación

| Caso | Entrada | Resultado |
|---|---|---|
| Coste cero | `[0]` | `0` |
| Carta intermedia | `[3]` | `6` |
| Carta de mayor coste | `[8]` | `16` |

### Requisitos de aprendizaje

- Definir y llamar una función que calcule el resultado.

### Contrato de la función

Conserva la firma proporcionada. El juego realiza las llamadas; devuelve el resultado, sin sustituirlo por un mensaje.

- {"args": [0], "value": 0, "label": "Coste cero"}
- {"args": [3], "value": 6, "label": "Carta intermedia"}
- {"args": [8], "value": 16, "label": "Carta de mayor coste"}

### Tu margen de decisión

Puedes cambiar nombres y organizar el código de otra forma, salvo firmas, tablas, archivos o técnicas exigidos arriba. La propuesta del cuaderno es una solución posible. En «Probar cambios» puedes explorar otros datos sin alterar tu borrador ni ganar recompensas.


Devuelve el doble del coste recibido. El archivo conserva una función; el motor la prueba con tres costes.

### Casos de comprobación

| Caso | Entrada | Resultado |
|---|---|---|
| Coste cero | `[0]` | `0` |
| Carta intermedia | `[3]` | `6` |
| Carta de mayor coste | `[8]` | `16` |


### Leer la propuesta

- `def valorar(coste):`: La cabecera define el nombre y los parámetros que recibirá la función.
- `return coste * 2`: Entrega este valor al código que llamó a la función; no equivale a mostrarlo en pantalla.

### Prueba otra decisión

En Probar cambios cambia un dato o un tamaño y compara la salida. Vuelve al objetivo para comprobar los casos de la misión. Si aparecen dos bucles, identifica qué recorre cada uno; si aparece una dirección, distingue el puntero de su destino.