texto = "18"
try:
    edad = int(texto)
    print(edad + 1)
except ValueError:
    print("Entrada no valida")
