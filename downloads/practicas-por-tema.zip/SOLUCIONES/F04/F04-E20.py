color = (10, 30, 50)
ficha = {"nombre": "Azul", "puntos": 3}
ficha["puntos"] += 4
print(color[1])
print(ficha["nombre"], ficha["puntos"])
