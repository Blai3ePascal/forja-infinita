def repartir(filas, columnas):
    total = 0
    for fila in range(filas):
        for columna in range(columnas):
            total += 1
    return total
