### El encargo

Construye las herramientas que harán funcionar la forja: datos, decisiones y funciones.

Cuenta cada casilla de la mesa con dos bucles anidados. Esta misión exige el recorrido: filas * columnas calcula el mismo número, pero no practica el objetivo.

### Casos de comprobación

| Caso | Entrada | Resultado |
|---|---|---|
| Tablero rectangular | `[2, 3]` | `6` |
| Sin filas | `[0, 4]` | `0` |
| Otro tamaño | `[3, 5]` | `15` |

### Requisitos de aprendizaje

- Definir y llamar una función que calcule el resultado.
- Usar dos bucles anidados dentro de la función; ambos deben participar en el cálculo.

### Contrato de la función

Conserva la firma proporcionada. El juego realiza las llamadas; devuelve el resultado, sin sustituirlo por un mensaje.

- {"args": [2, 3], "value": 6, "label": "Tablero rectangular"}
- {"args": [0, 4], "value": 0, "label": "Sin filas"}
- {"args": [3, 5], "value": 15, "label": "Otro tamaño"}

### Tu margen de decisión

Puedes cambiar nombres y organizar el código de otra forma, salvo firmas, tablas, archivos o técnicas exigidos arriba. La propuesta del cuaderno es una solución posible. En «Probar cambios» puedes explorar otros datos sin alterar tu borrador ni ganar recompensas.


Cuenta cada casilla de la mesa con dos bucles anidados. Esta misión exige el recorrido: filas * columnas calcula el mismo número, pero no practica el objetivo.

### Casos de comprobación

| Caso | Entrada | Resultado |
|---|---|---|
| Tablero rectangular | `[2, 3]` | `6` |
| Sin filas | `[0, 4]` | `0` |
| Otro tamaño | `[3, 5]` | `15` |


### Leer la propuesta

- `def repartir(filas, columnas):`: La cabecera define el nombre y los parámetros que recibirá la función.
- `total = 0`: Conserva o actualiza este dato antes de la siguiente operación. Puedes consultar cada palabra en el glosario.
- `for fila in range(filas):`: El bucle recorre un conjunto de valores. Su cuerpo cambia el estado en cada iteración; un segundo bucle recorre combinaciones.
- `for columna in range(columnas):`: El bucle recorre un conjunto de valores. Su cuerpo cambia el estado en cada iteración; un segundo bucle recorre combinaciones.
- `total += 1`: Conserva o actualiza este dato antes de la siguiente operación. Puedes consultar cada palabra en el glosario.
- `return total`: Entrega este valor al código que llamó a la función; no equivale a mostrarlo en pantalla.

### Prueba otra decisión

En Probar cambios cambia un dato o un tamaño y compara la salida. Vuelve al objetivo para comprobar los casos de la misión. Si aparecen dos bucles, identifica qué recorre cada uno; si aparece una dirección, distingue el puntero de su destino.