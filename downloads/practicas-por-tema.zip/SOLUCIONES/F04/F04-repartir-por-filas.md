Cuenta cada casilla de la mesa con dos bucles anidados. Esta misión exige el recorrido: filas * columnas calcula el mismo número, pero no practica el objetivo.

### Casos de comprobación

| Caso | Entrada | Resultado |
|---|---|---|
| Tablero rectangular | `[2, 3]` | `6` |
| Sin filas | `[0, 4]` | `0` |
| Otro tamaño | `[3, 5]` | `15` |

## Propuesta explicada

Cuenta cada casilla de la mesa con dos bucles anidados. Esta misión exige el recorrido: filas * columnas calcula el mismo número, pero no practica el objetivo.

### Casos de comprobación

| Caso | Entrada | Resultado |
|---|---|---|
| Tablero rectangular | `[2, 3]` | `6` |
| Sin filas | `[0, 4]` | `0` |
| Otro tamaño | `[3, 5]` | `15` |


### Leer la propuesta

- `def repartir(filas, columnas):`: La cabecera define el nombre y los parámetros que recibirá la función.
- `total = 0`: Conserva o actualiza este dato antes de la siguiente operación. Puedes consultar cada palabra en el glosario.
- `for fila in range(filas):`: El bucle recorre un conjunto de valores. Su cuerpo cambia el estado en cada iteración; un segundo bucle recorre combinaciones.
- `for columna in range(columnas):`: El bucle recorre un conjunto de valores. Su cuerpo cambia el estado en cada iteración; un segundo bucle recorre combinaciones.
- `total += 1`: Conserva o actualiza este dato antes de la siguiente operación. Puedes consultar cada palabra en el glosario.
- `return total`: Entrega este valor al código que llamó a la función; no equivale a mostrarlo en pantalla.

### Prueba otra decisión

En Laboratorio libre cambia un dato o un tamaño y compara la salida. Vuelve al objetivo para comprobar los casos de la misión. Si aparecen dos bucles, identifica qué recorre cada uno; si aparece una dirección, distingue el puntero de su destino.