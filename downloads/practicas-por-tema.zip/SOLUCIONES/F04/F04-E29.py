def resumen(*puntos, **datos):
    return datos["nombre"], sum(puntos)
print(resumen(2, 3, nombre="Azul"))
