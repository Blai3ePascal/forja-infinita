### El encargo

Construye las herramientas que harán funcionar la forja: datos, decisiones y funciones.

Devuelve un entero no negativo o None si el texto no representa una puja válida. Trata ValueError de forma específica.

### Casos de comprobación

| Caso | Entrada | Resultado |
|---|---|---|
| Puja válida | `["12"]` | `12` |
| Conversión rechazada | `["hola"]` | `null` |
| Rango rechazado | `["-3"]` | `null` |

### Requisitos de aprendizaje

- Definir y llamar una función que calcule el resultado.
- Gestionar errores de conversión con try/except.
- Capturar ValueError de forma específica.

### Contrato de la función

Conserva la firma proporcionada. El juego realiza las llamadas; devuelve el resultado, sin sustituirlo por un mensaje.

- {"args": ["12"], "value": 12, "label": "Puja válida"}
- {"args": ["hola"], "value": null, "label": "Conversión rechazada"}
- {"args": ["-3"], "value": null, "label": "Rango rechazado"}

### Tu margen de decisión

Puedes cambiar nombres y organizar el código de otra forma, salvo firmas, tablas, archivos o técnicas exigidos arriba. La propuesta del cuaderno es una solución posible. En «Probar cambios» puedes explorar otros datos sin alterar tu borrador ni ganar recompensas.


Devuelve un entero no negativo o None si el texto no representa una puja válida. Trata ValueError de forma específica.

### Casos de comprobación

| Caso | Entrada | Resultado |
|---|---|---|
| Puja válida | `["12"]` | `12` |
| Conversión rechazada | `["hola"]` | `null` |
| Rango rechazado | `["-3"]` | `null` |


### Leer la propuesta

- `def aceptar(texto):`: La cabecera define el nombre y los parámetros que recibirá la función.
- `try:`: Agrupa la operación que puede generar ValueError al convertir el texto.
- `valor = int(texto)`: Conserva o actualiza este dato antes de la siguiente operación. Puedes consultar cada palabra en el glosario.
- `return valor if valor >= 0 else None`: Entrega este valor al código que llamó a la función; no equivale a mostrarlo en pantalla.
- `except ValueError:`: Esta rama responde al error de conversión concreto, sin ocultar otros fallos.
- `return None`: Entrega este valor al código que llamó a la función; no equivale a mostrarlo en pantalla.

### Prueba otra decisión

En Probar cambios cambia un dato o un tamaño y compara la salida. Vuelve al objetivo para comprobar los casos de la misión. Si aparecen dos bucles, identifica qué recorre cada uno; si aparece una dirección, distingue el puntero de su destino.