Devuelve un entero no negativo o None si el texto no representa una puja válida. Trata ValueError de forma específica.

### Casos de comprobación

| Caso | Entrada | Resultado |
|---|---|---|
| Puja válida | `["12"]` | `12` |
| Conversión rechazada | `["hola"]` | `null` |
| Rango rechazado | `["-3"]` | `null` |

Devuelve un entero no negativo o None si el texto no representa una puja válida. Trata ValueError de forma específica.

### Casos de comprobación

| Caso | Entrada | Resultado |
|---|---|---|
| Puja válida | `["12"]` | `12` |
| Conversión rechazada | `["hola"]` | `null` |
| Rango rechazado | `["-3"]` | `null` |


### Leer la propuesta

- `def aceptar(texto):`: La cabecera define el nombre y los parámetros que recibirá la función.
- `try:`: Agrupa la operación que puede generar ValueError al convertir el texto.
- `valor = int(texto)`: Conserva o actualiza este dato antes de la siguiente operación. Puedes consultar cada palabra en el glosario.
- `return valor if valor >= 0 else None`: Entrega este valor al código que llamó a la función; no equivale a mostrarlo en pantalla.
- `except ValueError:`: Esta rama responde al error de conversión concreto, sin ocultar otros fallos.
- `return None`: Entrega este valor al código que llamó a la función; no equivale a mostrarlo en pantalla.

### Prueba otra decisión

En Probar cambios cambia un dato o un tamaño y compara la salida. Vuelve al objetivo para comprobar los casos de la misión. Si aparecen dos bucles, identifica qué recorre cada uno; si aparece una dirección, distingue el puntero de su destino.