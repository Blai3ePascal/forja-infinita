color = (20, 40, 60)
ficha = {"nombre": "Azul", "puntos": 3}
ficha["puntos"] += 2
print(color[1])
print(ficha["nombre"], ficha["puntos"])
