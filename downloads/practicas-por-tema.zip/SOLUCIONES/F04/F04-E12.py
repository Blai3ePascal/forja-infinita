notas = [0, 10]
total = 0
for nota in notas:
    total += nota
print(total / len(notas))
print(notas[0])
