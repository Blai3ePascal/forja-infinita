from datetime import date
fecha = date(2026, 11, 5)
nota = 8
print(fecha.strftime("%d/%m/%Y"))
print(f"Nota: {nota:.2f}")
