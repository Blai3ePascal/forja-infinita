def tarifa(edad):
    if edad < 18:
        return 5
    if edad >= 65:
        return 7
    return 10


for edad in [17, 18, 64, 65]:
    print(edad, tarifa(edad))
