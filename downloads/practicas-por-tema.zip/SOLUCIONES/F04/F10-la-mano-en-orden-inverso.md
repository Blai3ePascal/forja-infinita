### El encargo

Construye las herramientas que harán funcionar la forja: datos, decisiones y funciones.

Devuelve una lista con las cartas en orden inverso, conservando la original. Puedes usar un corte o construir otra lista.

### Casos de comprobación

| Caso | Entrada | Resultado |
|---|---|---|
| Tres cartas | `[[2, 7, 4]]` | `[4, 7, 2]` |
| Mano vacía | `[[]]` | `[]` |
| Una carta | `[[5]]` | `[5]` |

### Requisitos de aprendizaje

- Consultar o transformar la colección; no sustituirla por mensajes ya calculados.
- Conservar los argumentos originales y devolver una colección nueva.

### Contrato de la función

Conserva la firma proporcionada. El juego realiza las llamadas; devuelve el resultado, sin sustituirlo por un mensaje.

- {"args": [[2, 7, 4]], "value": [4, 7, 2], "label": "Tres cartas"}
- {"args": [[]], "value": [], "label": "Mano vacía"}
- {"args": [[5]], "value": [5], "label": "Una carta"}

### Tu margen de decisión

Puedes cambiar nombres y organizar el código de otra forma, salvo firmas, tablas, archivos o técnicas exigidos arriba. La propuesta del cuaderno es una solución posible. En «Probar cambios» puedes explorar otros datos sin alterar tu borrador ni ganar recompensas.


Devuelve una lista con las cartas en orden inverso, conservando la original. Puedes usar un corte o construir otra lista.

### Casos de comprobación

| Caso | Entrada | Resultado |
|---|---|---|
| Tres cartas | `[[2, 7, 4]]` | `[4, 7, 2]` |
| Mano vacía | `[[]]` | `[]` |
| Una carta | `[[5]]` | `[5]` |


### Leer la propuesta

- `def invertir(mano):`: La cabecera define el nombre y los parámetros que recibirá la función.
- `return mano[::-1]`: Entrega este valor al código que llamó a la función; no equivale a mostrarlo en pantalla.

### Prueba otra decisión

En Probar cambios cambia un dato o un tamaño y compara la salida. Vuelve al objetivo para comprobar los casos de la misión. Si aparecen dos bucles, identifica qué recorre cada uno; si aparece una dirección, distingue el puntero de su destino.