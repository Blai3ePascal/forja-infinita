def simular(direcciones):
    lineas = [None, None]
    aciertos = fallos = 0
    for direccion in direcciones:
        if type(direccion) is not int or direccion < 0:
            raise ValueError('Direccion no negativa requerida')
        bloque = direccion // 4
        linea = bloque % 2
        if lineas[linea] == bloque:
            aciertos += 1
        else:
            fallos += 1
            lineas[linea] = bloque
    return aciertos, fallos

for traza in [[0,4,0,4], [0,8,0,8], [0,0,0,0]]:
    aciertos, fallos = simular(traza)
    assert aciertos + fallos == len(traza)
    print(traza, 'aciertos:', aciertos, 'fallos:', fallos)
assert simular([0,4,0,4]) == (2,2)
assert simular([0,8,0,8]) == (0,4)
assert simular([]) == (0,0)
