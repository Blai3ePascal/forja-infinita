import csv, math, platform, timeit
from statistics import median
from pathlib import Path
datos = list(range(20000))
def suma_bucle():
    total = 0
    for valor in datos:
        total += valor
    return total

def suma_integrada():
    return sum(datos)

esperado = len(datos) * (len(datos) - 1) // 2
assert suma_bucle() == suma_integrada() == esperado
filas = []
for nombre, funcion in [('bucle', suma_bucle), ('sum', suma_integrada)]:
    muestras = [t / 10 for t in timeit.repeat(funcion, repeat=5, number=10)]
    assert all(math.isfinite(t) and t > 0 for t in muestras)
    filas.append({'metodo':nombre,'n':len(datos),'repeticiones':5,'llamadas_bloque':10,'min_s':min(muestras),'mediana_s':median(muestras),'python':platform.python_version(),'arquitectura':platform.machine()})
ruta = Path('rendimiento.csv')
with ruta.open('w', encoding='utf-8', newline='') as archivo:
    w = csv.DictWriter(archivo, fieldnames=list(filas[0]))
    w.writeheader(); w.writerows(filas)
with ruta.open(encoding='utf-8', newline='') as archivo:
    recuperadas = list(csv.DictReader(archivo))
assert len(recuperadas) == 2
assert all(float(f['mediana_s']) > 0 for f in recuperadas)
print('Resultado comun:', esperado)
print('Metodos:', [f['metodo'] for f in recuperadas])
print('Muestras por metodo: 5; llamadas por muestra: 10')
print('Medidas variables guardadas y reabiertas: rendimiento.csv')
print('Ambos recorren n datos: la medida no demuestra una cota distinta')
