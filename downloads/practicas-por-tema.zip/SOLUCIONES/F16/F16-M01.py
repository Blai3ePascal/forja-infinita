# Modelo de dos lecturas y una suma: no es un microprocesador completo.
memoria = [7, 5]
acumulador = memoria[0]
print('Tras cargar:', acumulador)
acumulador += memoria[1]
print('Tras sumar:', acumulador)
print('Memoria conservada:', memoria)
