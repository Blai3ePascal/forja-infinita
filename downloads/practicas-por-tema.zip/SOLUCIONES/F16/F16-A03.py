import dis
def operacion(a, b):
    return a - b

print(operacion(7, 5))
print(any(i.opname == "BINARY_OP" for i in dis.get_instructions(operacion)))
