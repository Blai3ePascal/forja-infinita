### El encargo

El archivo de la forja necesita localizar y ordenar información con un procedimiento preciso.

Define ambos datos, comprueba si hay saldo y descuenta el precio solo dentro de la condición. Muestra el saldo al final. Ordena los bloques con Subir y Bajar; después se ejecuta Python real.

### Requisitos de aprendizaje

- Mostrar valores obtenidos de los datos; no escribir todos los resultados como literales.

### Resultado de referencia

```text
4
```

### Tu margen de decisión

Puedes cambiar nombres y organizar el código de otra forma, salvo firmas, tablas, archivos o técnicas exigidos arriba. La propuesta del cuaderno es una solución posible. En «Probar cambios» puedes explorar otros datos sin alterar tu borrador ni ganar recompensas.


Define ambos datos, comprueba si hay saldo y descuenta el precio solo dentro de la condición. Muestra el saldo al final.

El orden expresa dependencias: un nombre necesita tener valor antes de usarlo. La sangría mantiene el cuerpo de una condición, bucle o función como un bloque. Cambia el precio o los valores en Probar cambios para contrastar otra entrada.