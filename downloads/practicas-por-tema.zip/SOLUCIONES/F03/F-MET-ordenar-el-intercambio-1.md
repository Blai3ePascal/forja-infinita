### El encargo

El archivo de la forja necesita localizar y ordenar información con un procedimiento preciso.

Ordena las instrucciones para definir saldo y precio, descontar la compra y mostrar el saldo. Después se ejecuta el Python real.

### Requisitos de aprendizaje

- Mostrar valores obtenidos de los datos; no escribir todos los resultados como literales.

### Resultado de referencia

```text
4
```

### Tu margen de decisión

Puedes cambiar nombres y organizar el código de otra forma, salvo firmas, tablas, archivos o técnicas exigidos arriba. La propuesta del cuaderno es una solución posible. En «Probar cambios» puedes explorar otros datos sin alterar tu borrador ni ganar recompensas.


Ordena las instrucciones para definir saldo y precio, descontar la compra y mostrar el saldo. Después se ejecuta el Python real.

### Leer la propuesta

- `saldo = 5`: Conserva o actualiza este dato antes de la siguiente operación. Puedes consultar cada palabra en el glosario.
- `precio = 1`: Conserva o actualiza este dato antes de la siguiente operación. Puedes consultar cada palabra en el glosario.
- `saldo = saldo - precio`: Conserva o actualiza este dato antes de la siguiente operación. Puedes consultar cada palabra en el glosario.
- `print(saldo)`: Presenta el resultado para observarlo y compararlo. El salto de línea separa los resultados.

### Prueba otra decisión

En Probar cambios cambia un dato o un tamaño y compara la salida. Vuelve al objetivo para comprobar los casos de la misión. Si aparecen dos bucles, identifica qué recorre cada uno; si aparece una dirección, distingue el puntero de su destino.