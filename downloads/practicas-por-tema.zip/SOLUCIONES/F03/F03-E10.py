datos = [2, 4, 7, 9, 12]
buscado = 12
izquierda, derecha = 0, len(datos) - 1
posicion = -1
while izquierda <= derecha:
    medio = (izquierda + derecha) // 2
    if datos[medio] == buscado:
        posicion = medio
        break
    if datos[medio] < buscado:
        izquierda = medio + 1
    else:
        derecha = medio - 1
print(posicion)
