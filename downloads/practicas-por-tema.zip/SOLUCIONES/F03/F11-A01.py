def ordenar(datos):
    a = datos.copy()
    comparaciones = 0
    for i in range(len(a) - 1):
        minimo = i
        for j in range(i + 1, len(a)):
            comparaciones += 1
            if a[j] < a[minimo]:
                minimo = j
        a[i], a[minimo] = a[minimo], a[i]
    return a, comparaciones


from collections import Counter

casos = [[], [7], [3, 1, 3, -2], [1, 2, 3, 4], [4, 3, 2, 1]]
for caso in casos:
    antes = caso.copy()
    salida, comparaciones = ordenar(caso)
    assert salida == sorted(caso)
    assert Counter(salida) == Counter(caso)
    assert caso == antes
    print(caso, "->", salida, "comparaciones:", comparaciones)
for n in [4, 8]:
    asc = list(range(n))
    desc = list(reversed(asc))
    print("n:", n, "ordenado:", ordenar(asc)[1], "inverso:", ordenar(desc)[1])
