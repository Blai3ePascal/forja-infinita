datos = [-8, -3, -5]
mayor = datos[0]
for valor in datos[1:]:
    if valor > mayor:
        mayor = valor
print(mayor)
