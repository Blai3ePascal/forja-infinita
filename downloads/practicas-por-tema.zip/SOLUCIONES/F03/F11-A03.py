def ordenar(datos):
    a = datos.copy()
    comparaciones = 0
    for limite in range(len(a) - 1, 0, -1):
        cambio = False
        for j in range(limite):
            comparaciones += 1
            if a[j] > a[j + 1]:
                a[j], a[j + 1] = a[j + 1], a[j]
                cambio = True
        if not cambio:
            break
    return a, comparaciones


from collections import Counter

casos = [[], [7], [3, 1, 3, -2], [1, 2, 3, 4], [4, 3, 2, 1]]
for caso in casos:
    antes = caso.copy()
    salida, comparaciones = ordenar(caso)
    assert salida == sorted(caso)
    assert Counter(salida) == Counter(caso)
    assert caso == antes
    print(caso, "->", salida, "comparaciones:", comparaciones)
for n in [4, 8]:
    asc = list(range(n))
    desc = list(reversed(asc))
    print("n:", n, "ordenado:", ordenar(asc)[1], "inverso:", ordenar(desc)[1])
