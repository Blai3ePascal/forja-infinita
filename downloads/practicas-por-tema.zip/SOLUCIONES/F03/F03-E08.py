datos = [2, 4, 7, 9]
for buscado in [9, 6]:
    posicion = -1
    for i in range(len(datos)):
        if datos[i] == buscado:
            posicion = i
            break
    print(posicion)
