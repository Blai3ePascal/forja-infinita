### El encargo

El archivo de la forja necesita localizar y ordenar información con un procedimiento preciso.

Crea el acumulador antes del bucle. Cada valor aporta al total y el resultado se muestra tras terminar el recorrido. Ordena los bloques con Subir y Bajar; después se ejecuta Python real.

### Requisitos de aprendizaje

- Mostrar valores obtenidos de los datos; no escribir todos los resultados como literales.

### Resultado de referencia

```text
6
```

### Tu margen de decisión

Puedes cambiar nombres y organizar el código de otra forma, salvo firmas, tablas, archivos o técnicas exigidos arriba. La propuesta del cuaderno es una solución posible. En «Probar cambios» puedes explorar otros datos sin alterar tu borrador ni ganar recompensas.


Crea el acumulador antes del bucle. Cada valor aporta al total y el resultado se muestra tras terminar el recorrido.

El orden expresa dependencias: un nombre necesita tener valor antes de usarlo. La sangría mantiene el cuerpo de una condición, bucle o función como un bloque. Cambia el precio o los valores en Probar cambios para contrastar otra entrada.