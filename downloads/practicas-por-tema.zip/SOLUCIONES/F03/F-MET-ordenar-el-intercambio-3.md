Crea el acumulador antes del bucle. Cada valor aporta al total y el resultado se muestra tras terminar el recorrido. Ordena los bloques con Subir y Bajar; después se ejecuta Python real.

Crea el acumulador antes del bucle. Cada valor aporta al total y el resultado se muestra tras terminar el recorrido.

El orden expresa dependencias: un nombre necesita tener valor antes de usarlo. La sangría mantiene el cuerpo de una condición, bucle o función como un bloque. Cambia el precio o los valores en Probar cambios para contrastar otra entrada.