saldo = 5
precio = 1
saldo = saldo - precio
print(saldo)
