total = 0
for valor in [1, 2, 3]:
    total += valor
print(total)
