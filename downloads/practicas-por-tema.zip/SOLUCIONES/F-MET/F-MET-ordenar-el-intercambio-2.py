saldo = 6
precio = 2
if precio <= saldo:
    saldo = saldo - precio
print(saldo)
