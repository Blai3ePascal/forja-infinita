Define la función antes de llamarla, prepara el argumento y conserva el valor devuelto antes de mostrarlo. Ordena los bloques con Subir y Bajar; después se ejecuta Python real.

## Propuesta explicada

Define la función antes de llamarla, prepara el argumento y conserva el valor devuelto antes de mostrarlo.

El orden expresa dependencias: un nombre necesita tener valor antes de usarlo. La sangría mantiene el cuerpo de una condición, bucle o función como un bloque. Cambia el precio o los valores en Laboratorio libre para contrastar otra entrada.