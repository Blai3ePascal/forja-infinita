Ordena las instrucciones para definir saldo y precio, descontar la compra y mostrar el saldo. Después se ejecuta el Python real.

## Propuesta explicada

Ordena las instrucciones para definir saldo y precio, descontar la compra y mostrar el saldo. Después se ejecuta el Python real.

### Leer la propuesta

- `saldo = 5`: Conserva o actualiza este dato antes de la siguiente operación. Puedes consultar cada palabra en el glosario.
- `precio = 1`: Conserva o actualiza este dato antes de la siguiente operación. Puedes consultar cada palabra en el glosario.
- `saldo = saldo - precio`: Conserva o actualiza este dato antes de la siguiente operación. Puedes consultar cada palabra en el glosario.
- `print(saldo)`: Presenta el resultado para observarlo y compararlo. El salto de línea separa los resultados.

### Prueba otra decisión

En Laboratorio libre cambia un dato o un tamaño y compara la salida. Vuelve al objetivo para comprobar los casos de la misión. Si aparecen dos bucles, identifica qué recorre cada uno; si aparece una dirección, distingue el puntero de su destino.