def valorar(coste):
    return coste * 2
precio = 3
resultado = valorar(precio)
print(resultado)
