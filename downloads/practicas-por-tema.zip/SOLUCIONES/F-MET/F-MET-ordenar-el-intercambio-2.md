Define ambos datos, comprueba si hay saldo y descuenta el precio solo dentro de la condición. Muestra el saldo al final. Ordena los bloques con Subir y Bajar; después se ejecuta Python real.

Define ambos datos, comprueba si hay saldo y descuenta el precio solo dentro de la condición. Muestra el saldo al final.

El orden expresa dependencias: un nombre necesita tener valor antes de usarlo. La sangría mantiene el cuerpo de una condición, bucle o función como un bloque. Cambia el precio o los valores en Laboratorio libre para contrastar otra entrada.