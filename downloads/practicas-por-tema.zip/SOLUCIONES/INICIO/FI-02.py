cristales = 5
print(cristales * 2)
