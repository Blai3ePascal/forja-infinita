inventario = [2, 5, 8]
for cantidad in reversed(inventario):
    print(cantidad)
