for lote in range(1, 5):
    print(lote)
