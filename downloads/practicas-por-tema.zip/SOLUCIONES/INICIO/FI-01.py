print(3)
