import sqlite3

with sqlite3.connect(":memory:") as db:
    db.execute(("CREATE TABLE recurso(id INTEGER PRIMARY " "KEY, nombre TEXT)"))
    db.executescript(
        ("INSERT INTO recurso VALUES(1, NULL); INSERT " "INTO recurso VALUES(2, '');")
    )
    print(db.execute("SELECT id FROM recurso WHERE nombre IS NULL").fetchall())
