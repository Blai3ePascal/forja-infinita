import sqlite3

with sqlite3.connect(":memory:") as db:
    db.execute(("CREATE TABLE equipo(id INTEGER PRIMARY KEY, " "nombre TEXT NOT NULL)"))
    db.execute("INSERT INTO equipo VALUES(1, 'Azul')")
    db.execute("INSERT INTO equipo VALUES(2, 'Verde')")
    print(db.execute("SELECT nombre FROM equipo ORDER BY id").fetchall())
