print("Sala", 8)
print("Turno", 3)
print("Preparados")
