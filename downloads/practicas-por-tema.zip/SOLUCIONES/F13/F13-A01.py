import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

datos = np.array([1, 2, 2, 3, 4, 5, 8, 9], dtype=float)
fig, ejes = plt.subplots(1, 3, figsize=(12, 4))
for ax, n in zip(ejes[:2], [2, 4]):
    frecuencias, bordes = np.histogram(datos, bins=n)
    ax.hist(datos, bins=bordes, edgecolor='black', color='#238b8d')
    ax.set(xlabel='Duracion (min)', ylabel='Observaciones', title=f'{n} intervalos')
    print(n, 'intervalos:', frecuencias.tolist(), 'bordes:', bordes.tolist())
    assert int(frecuencias.sum()) == len(datos)
ejes[2].boxplot(datos, whis=1.5)
ejes[2].set(xticks=[1], xticklabels=['Grupo unico'], ylabel='Duracion (min)', title='Caja: bigotes 1.5 IQR')
fig.tight_layout()
fig.savefig('histogramas_caja.png', dpi=120)
plt.close(fig)
print('Mediana:', float(np.median(datos)))
print('Archivo: histogramas_caja.png')
