import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

from datetime import date
observaciones = [('2026-01-03',18), ('2026-01-01',10), ('2026-01-02',14)]
ordenadas = sorted((date.fromisoformat(fecha), venta) for fecha, venta in observaciones)
fechas = [fecha for fecha, venta in ordenadas]
ventas = [venta for fecha, venta in ordenadas]
movil = [None] + [(ventas[i-1] + ventas[i]) / 2 for i in range(1, len(ventas))]
fig, ax = plt.subplots(figsize=(7, 4))
ax.plot(fechas, ventas, marker='o', label='Observado')
ax.plot(fechas[1:], movil[1:], marker='s', label='Media movil, 2 observaciones')
ax.set(xlabel='Fecha', ylabel='Ventas (unidades)', title='Orden temporal y ventana de dos datos')
fig.autofmt_xdate(); ax.legend(); fig.tight_layout(); fig.savefig('serie_temporal.png', dpi=120); plt.close(fig)
print('Fechas:', [f.isoformat() for f in fechas])
print('Ventas:', ventas)
print('Medias moviles:', movil)
assert ventas == [10, 14, 18]
assert movil == [None, 12., 16.]
