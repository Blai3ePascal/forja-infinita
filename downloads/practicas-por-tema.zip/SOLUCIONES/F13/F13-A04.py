import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

def kde(datos, rejilla, h):
    if h <= 0 or not len(datos):
        raise ValueError('Datos y ancho positivo requeridos')
    z = (rejilla[:, None] - datos[None, :]) / h
    return np.exp(-0.5 * z**2).mean(axis=1) / (h * np.sqrt(2 * np.pi))

datos = np.array([-1., 0., 1.])
rejilla = np.linspace(-6, 6, 1201)
fig, ax = plt.subplots(figsize=(7, 4))
for h in [.25, 1.0]:
    densidad = kde(datos, rejilla, h)
    area = float(np.sum((densidad[:-1] + densidad[1:]) * np.diff(rejilla) / 2))
    assert abs(area - 1) < .001
    print('Ancho:', h, 'area aprox.:', f'{area:.3f}')
    ax.plot(rejilla, densidad, label=f'h={h}')
ax.plot(datos, np.zeros_like(datos), '|', color='black', markersize=12)
ax.set(xlabel='Medida (u)', ylabel='Densidad (1/u)', title='Mismos datos, distinto suavizado')
ax.legend(); fig.tight_layout(); fig.savefig('kde_anchos.png', dpi=120); plt.close(fig)
try:
    kde(datos, rejilla, 0)
except ValueError as error:
    print(error)
