import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

import pandas as pd
df = pd.DataFrame({'a':[1,2,3,4], 'b':[2,4,6,8], 'c':[4,3,2,1], 'constante':[5,5,5,5]})
columnas = [col for col in df if df[col].var(ddof=0) > 0]
corr = df[columnas].corr()
fig, ax = plt.subplots(figsize=(6, 5))
im = ax.imshow(corr.to_numpy(), vmin=-1, vmax=1, cmap='coolwarm')
ax.set(xticks=range(len(columnas)), yticks=range(len(columnas)), xticklabels=columnas, yticklabels=columnas, title='Asociacion lineal de tres variables')
for i in range(len(columnas)):
    for j in range(len(columnas)):
        ax.text(j, i, f'{corr.iloc[i,j]:.1f}', ha='center', va='center', color='black', bbox=dict(facecolor='white', alpha=.8, edgecolor='none'))
fig.colorbar(im, ax=ax, label='Correlacion de Pearson')
fig.tight_layout(); fig.savefig('correlaciones.png', dpi=120); plt.close(fig)
print('Columnas:', columnas)
print('Matriz:', corr.to_numpy().round(6).tolist())
assert np.allclose(corr.to_numpy(), corr.to_numpy().T)
assert np.allclose(np.diag(corr), 1)
print('Excluida: constante, varianza cero')
