texto = "ñ"
print(len(texto))
print(len(texto.encode("utf-8")))
print(2 ** 8)
