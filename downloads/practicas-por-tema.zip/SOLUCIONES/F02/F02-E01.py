numero = 13
print(numero)
print(format(numero, "b"))
print(format(numero, "X"))
