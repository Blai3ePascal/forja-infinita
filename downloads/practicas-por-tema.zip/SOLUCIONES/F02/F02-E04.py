numero = 27
print(numero)
print(format(numero, "b"))
print(format(numero, "X"))
