def ampliar(inicial, nuevos, capacidad):
    if type(capacidad) is not int or capacidad < len(inicial) or capacidad < 0:
        raise ValueError('Capacidad incompatible')
    resultado, rechazados = inicial.copy(), []
    for valor in nuevos:
        if len(resultado) < capacidad:
            resultado.append(valor)
        else:
            rechazados.append(valor)
    return resultado, rechazados

inicial = [2, 4]
print(ampliar(inicial, [6, 8, 10], 4))
print(inicial)
assert ampliar([], [1], 0) == ([], [1])
assert ampliar([2], [], 1) == ([2], [])
assert ampliar([2], [3], 1) == ([2], [3])
try:
    ampliar([], [1], -1)
except ValueError as error:
    print(error)
else:
    raise AssertionError('Falta validar la capacidad')
