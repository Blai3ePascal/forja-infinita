original = [4, 7, 2]
alias = original
copia = original.copy()
alias[0] = 9
print(original)
print(copia)
print(alias is original, copia is original)
