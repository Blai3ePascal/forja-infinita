Devuelve una lista con las cartas en orden inverso, conservando la original. Puedes usar un corte o construir otra lista.

### Casos de comprobación

| Caso | Entrada | Resultado |
|---|---|---|
| Tres cartas | `[[2, 7, 4]]` | `[4, 7, 2]` |
| Mano vacía | `[[]]` | `[]` |
| Una carta | `[[5]]` | `[5]` |

## Propuesta explicada

Devuelve una lista con las cartas en orden inverso, conservando la original. Puedes usar un corte o construir otra lista.

### Casos de comprobación

| Caso | Entrada | Resultado |
|---|---|---|
| Tres cartas | `[[2, 7, 4]]` | `[4, 7, 2]` |
| Mano vacía | `[[]]` | `[]` |
| Una carta | `[[5]]` | `[5]` |


### Leer la propuesta

- `def invertir(mano):`: La cabecera define el nombre y los parámetros que recibirá la función.
- `return mano[::-1]`: Entrega este valor al código que llamó a la función; no equivale a mostrarlo en pantalla.

### Prueba otra decisión

En Laboratorio libre cambia un dato o un tamaño y compara la salida. Vuelve al objetivo para comprobar los casos de la misión. Si aparecen dos bucles, identifica qué recorre cada uno; si aparece una dirección, distingue el puntero de su destino.