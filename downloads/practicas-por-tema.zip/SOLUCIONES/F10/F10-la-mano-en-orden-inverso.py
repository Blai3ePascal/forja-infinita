def invertir(mano):
    return mano[::-1]
