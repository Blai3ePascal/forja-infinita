def consultar(datos, indice):
    if type(indice) is int and 0 <= indice < len(datos):
        return True, datos[indice]
    return False, None

for indice in [-1, 0, 2, 3, True]:
    print(indice, consultar([10, 20, 30], indice))
assert consultar([], 0) == (False, None)
assert consultar([None], 0) == (True, None)
assert consultar([7], 0.0) == (False, None)
print('Vacio:', consultar([], 0))
