def transponer(matriz):
    if not matriz:
        return []
    columnas = len(matriz[0])
    if any(len(fila) != columnas for fila in matriz):
        raise ValueError('Matriz no rectangular')
    resultado = []
    for columna in range(columnas):
        nueva = []
        for fila in range(len(matriz)):
            nueva.append(matriz[fila][columna])
        resultado.append(nueva)
    return resultado

matriz = [[1, 2, 3], [4, 5, 6]]
copia = [fila.copy() for fila in matriz]
copia[0][0] = 99
print(matriz)
print(copia)
print(transponer(matriz))
assert transponer([]) == []
assert transponer([[8]]) == [[8]]
assert transponer(transponer(matriz)) == matriz
try:
    transponer([[1], [2, 3]])
except ValueError as error:
    print(error)
else:
    raise AssertionError('Falta comprobar las filas')
