Un torneo tiene varias inscripciones. Una persona se inscribe en distintos torneos; la fecha de alta pertenece a la inscripción. No se permite repetir la pareja.

Dibuja las entidades y sus cardinalidades en papel; después escribe el esquema SQL.

Contrato de tablas y columnas (PK: clave primaria; FK: clave foránea):

personas(id INTEGER PK, nombre TEXT obligatorio); torneos(id INTEGER PK, nombre TEXT obligatorio); inscripciones(persona_id INTEGER FK→personas.id, torneo_id INTEGER FK→torneos.id, fecha TEXT obligatoria, PK compuesta persona_id+torneo_id).

Define las tablas en el orden necesario para que las referencias tengan destino. No insertes datos.

## Propuesta explicada

Un torneo tiene varias inscripciones. Una persona se inscribe en distintos torneos; la fecha de alta pertenece a la inscripción. No se permite repetir la pareja.

Cada entidad se transforma en una tabla con clave primaria. La relación 1:N introduce una clave foránea en el lado N. Una N:M crea una tabla intermedia con las dos claves; su clave primaria compuesta impide duplicar la pareja. Los atributos de la relación, como cantidad o fecha, se guardan en esa tabla intermedia.

En esta misión se verifican columnas y claves primarias en un caso, y las claves foráneas en otro. NOT NULL expresa datos obligatorios. CHECK(cantidad>0) evita cantidades sin sentido en el modelo.

La comprobación incluye obligatoriedad, unicidad y relaciones: se intentan insertar datos válidos e inválidos en savepoints que se revierten. El caso de cantidad cero debe fallar; el nombre, la fecha o el propietario obligatorios no pueden quedar a NULL. También se comprueba que el esquema se haya entregado sin filas precargadas.