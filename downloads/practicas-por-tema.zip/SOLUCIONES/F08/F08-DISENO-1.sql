CREATE TABLE personas(id INTEGER PRIMARY KEY,
                                 nombre TEXT NOT NULL);


CREATE TABLE mazos(id INTEGER PRIMARY KEY,
                              persona_id INTEGER NOT NULL REFERENCES personas(id),
                                                                     nombre TEXT NOT NULL);


CREATE TABLE cartas(id INTEGER PRIMARY KEY,
                               nombre TEXT NOT NULL);


CREATE TABLE contenido(mazo_id INTEGER REFERENCES mazos(id),
                                                  carta_id INTEGER REFERENCES cartas(id),
                                                                              cantidad INTEGER NOT NULL CHECK(cantidad>0),
                                                                                                        PRIMARY KEY(mazo_id,
                                                                                                                    carta_id));
