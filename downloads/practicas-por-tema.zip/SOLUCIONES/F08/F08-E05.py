import sqlite3
with sqlite3.connect(":memory:") as db:
    db.execute("PRAGMA foreign_keys=ON")
    db.execute("CREATE TABLE sala(id INTEGER PRIMARY KEY)")
    db.execute((
            "CREATE TABLE equipo(id INTEGER PRIMARY KEY, "
            "sala_id INTEGER NOT NULL REFERENCES "
            "sala(id))"
        ))
    db.execute("INSERT INTO sala VALUES(4)")
    db.execute("INSERT INTO equipo VALUES(1, 4)")
    print(db.execute("SELECT sala_id FROM equipo").fetchone()[0])
