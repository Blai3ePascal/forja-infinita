CREATE TABLE personas(id INTEGER PRIMARY KEY,nombre TEXT NOT NULL);
CREATE TABLE torneos(id INTEGER PRIMARY KEY,nombre TEXT NOT NULL);
CREATE TABLE inscripciones(persona_id INTEGER REFERENCES personas(id),torneo_id INTEGER REFERENCES torneos(id),fecha TEXT NOT NULL,PRIMARY KEY(persona_id,torneo_id));