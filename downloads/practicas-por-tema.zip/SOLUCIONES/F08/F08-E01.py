import sqlite3

with sqlite3.connect(":memory:") as db:
    db.execute(
        (
            "CREATE TABLE matricula(persona INTEGER NOT "
            "NULL, curso TEXT NOT NULL, periodo TEXT NOT "
            "NULL, PRIMARY KEY(persona, curso, periodo))"
        )
    )
    db.execute(("INSERT INTO matricula VALUES(1, 'Python', " "'2026')"))
    db.execute(("INSERT INTO matricula VALUES(1, 'Python', " "'2027')"))
    print(db.execute("SELECT COUNT(*) FROM matricula").fetchone()[0])
