from math import comb, exp, erf, sqrt, atan, pi
probabilidades = [
    ('Binomial(4,0.5): X=2', comb(4, 2) * .5**2 * .5**2),
    ('Poisson(2): X=0', exp(-2)),
    ('Normal(0,1): -1<=X<=1', erf(1 / sqrt(2))),
    ('Uniforme(0,4): 1<=X<=3', (3 - 1) / 4),
    ('Exponencial(tasa=2): X<=1', 1 - exp(-2)),
    ('Gamma(forma=2,escala=1): X<=1', 1 - exp(-1) * (1 + 1)),
    ('Beta(2,2): X<=0.5', 3 * .5**2 - 2 * .5**3),
    ('t(gl=1): -1<=X<=1', 2 * atan(1) / pi),
]
for nombre, probabilidad in probabilidades:
    assert 0 <= probabilidad <= 1
    print(nombre, '->', f'{probabilidad:.6f}')
print('Continuas: la probabilidad de un punto aislado es cero')
