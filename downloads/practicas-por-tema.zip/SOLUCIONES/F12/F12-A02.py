import numpy as np
valores = np.array([2., 4., 6., 8., 30.])
q1, mediana, q3 = np.quantile(valores, [.25, .5, .75], method='linear')
iqr = q3 - q1
inferior, superior = q1 - 1.5 * iqr, q3 + 1.5 * iqr
candidatos = valores[(valores < inferior) | (valores > superior)]
print('Cuartiles:', q1, mediana, q3)
print('IQR y limites:', iqr, inferior, superior)
print('Candidatos:', candidatos.tolist())
print('Cuatro datos:', np.quantile([2., 4., 6., 8.], [.25, .5, .75], method='linear').tolist())
assert candidatos.tolist() == [30.]
assert valores.tolist() == [2., 4., 6., 8., 30.]
