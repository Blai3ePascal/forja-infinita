import math
import pandas as pd

def dispersion(valores):
    if not valores or not all(math.isfinite(x) for x in valores):
        raise ValueError('Se requieren datos finitos')
    n = len(valores)
    media = sum(valores) / n
    cuadrados = sum((x - media) ** 2 for x in valores)
    poblacional = cuadrados / n
    muestral = cuadrados / (n - 1) if n > 1 else None
    return media, cuadrados, poblacional, muestral

media, cuadrados, vp, vm = dispersion([2., 4., 6., 8.])
print(media, cuadrados, vp, round(vm, 6))
print('Desviaciones:', round(math.sqrt(vp), 6), round(math.sqrt(vm), 6))
s = pd.Series([2., 4., 6., 8.])
assert math.isclose(vp, s.var(ddof=0))
assert math.isclose(vm, s.var(ddof=1))
print('Un dato:', dispersion([5.]))
