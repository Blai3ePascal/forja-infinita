Muestra las cartas de tipo Luz, por id.

### Datos de partida

- `personas(id, nombre)`: (1, Luna), (2, Mar), (3, Sol).
- `cartas(id, nombre, tipo, coste)`: (1, Faro, Luz, 2), (2, Marea, Agua, 5), (3, Brasa, Fuego, 3), (4, Aurora, Luz, 7).
- `coleccion(persona_id, carta_id, copias)`: (1,1,2), (1,2,1), (2,3,3).
- Claves primarias: `id` en personas/cartas y la pareja `(persona_id,carta_id)` en coleccion. Ambos id de coleccion son claves foráneas.

También se comprueba una base con la carta (5, Espejo, Luz, 1) y otra con la colección (3,4,4), por separado. Tu consulta debe funcionar al cambiar esos datos.

Muestra las cartas de tipo Luz, por id.

### Leer la propuesta

- `SELECT nombre FROM cartas WHERE tipo='Luz' ORDER BY id;`: SELECT construye el resultado a partir de las tablas, filtros y agrupaciones indicados.

### Prueba otra decisión

En Laboratorio libre cambia un dato o un tamaño y compara la salida. Vuelve al objetivo para comprobar los casos de la misión. Si aparecen dos bucles, identifica qué recorre cada uno; si aparece una dirección, distingue el puntero de su destino.

El motor compara valores y orden cuando se ha pedido, sin exigir el mismo nombre de alias ni la misma consulta. COUNT(*) cuenta filas; COUNT(carta_id) omite los NULL de las personas sin pareja. WHERE se aplica a filas y HAVING a grupos.