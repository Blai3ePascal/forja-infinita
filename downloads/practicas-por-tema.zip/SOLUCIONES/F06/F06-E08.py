def media(valores):
    if not valores:
        return None
    return sum(valores) / len(valores)
for caso in [[0], [-2, 2]]:
    print(media(caso))
