import numpy as np

valores = np.array([2.0, 4.0, 6.0, 8.0, 30.0])
q1, mediana, q3 = np.quantile(valores, [0.25, 0.5, 0.75], method="linear")
iqr = q3 - q1
inferior, superior = q1 - 1.5 * iqr, q3 + 1.5 * iqr
candidatos = valores[(valores < inferior) | (valores > superior)]
print("Cuartiles:", q1, mediana, q3)
print("IQR y limites:", iqr, inferior, superior)
print("Candidatos:", candidatos.tolist())
print(
    "Cuatro datos:",
    np.quantile([2.0, 4.0, 6.0, 8.0], [0.25, 0.5, 0.75], method="linear").tolist(),
)
assert candidatos.tolist() == [30.0]
assert valores.tolist() == [2.0, 4.0, 6.0, 8.0, 30.0]
