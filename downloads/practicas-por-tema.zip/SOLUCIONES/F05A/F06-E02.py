entradas = ["8", "", "once", "12", "6", "-1"]
validas = []
for texto in entradas:
    try:
        nota = float(texto)
    except ValueError:
        continue
    if 0 <= nota <= 10:
        validas.append(nota)
print(len(validas), len(entradas) - len(validas))
print(sum(validas) / len(validas) if validas else None)
