import pandas as pd

s = pd.Series([2.0, 4.0, 6.0, 8.0])
print("Media:", s.mean())
print("Varianza ddof=0:", s.var(ddof=0))
print("Varianza ddof=1:", round(s.var(ddof=1), 6))
