import pandas as pd

datos = pd.DataFrame({"ventas": [10, None, 30]})
print(int(datos["ventas"].isna().sum()))
print(datos["ventas"].mean())
print(datos["ventas"].fillna(0).mean())
