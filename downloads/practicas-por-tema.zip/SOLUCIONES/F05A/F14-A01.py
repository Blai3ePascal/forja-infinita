import csv, math
from pathlib import Path

ruta = Path("notas.csv")
ruta.write_text("id,nota\n1,8\n2,\n3,abc\n4,11\n5,6\n6,nan\n", encoding="utf-8")
validas, rechazadas = [], []
with ruta.open(encoding="utf-8", newline="") as archivo:
    lector = csv.DictReader(archivo)
    if lector.fieldnames != ["id", "nota"]:
        raise ValueError("Cabecera inesperada")
    for numero, fila in enumerate(lector, start=2):
        texto = (fila["nota"] or "").strip()
        motivo = None
        if not texto:
            motivo = "ausente"
        else:
            try:
                nota = float(texto)
            except ValueError:
                motivo = "no numerico"
            else:
                if not math.isfinite(nota):
                    motivo = "no finito"
                elif not 0 <= nota <= 10:
                    motivo = "fuera de rango"
        if motivo is None:
            validas.append((fila["id"], nota))
        else:
            rechazadas.append((numero, fila["id"], motivo))
print("Validas:", validas)
print("Rechazadas:", rechazadas)
print(
    "Balance:", len(validas), "+", len(rechazadas), "=", len(validas) + len(rechazadas)
)
assert validas == [("1", 8.0), ("5", 6.0)]
assert len(rechazadas) == 4
