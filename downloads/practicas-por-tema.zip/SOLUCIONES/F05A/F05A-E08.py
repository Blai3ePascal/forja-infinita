import pandas as pd

datos = pd.Series([10, 12, 14, 100, 100])
print(datos.mean())
print(datos.median())
print(pd.Series([10, 10, 12]).duplicated().sum())
