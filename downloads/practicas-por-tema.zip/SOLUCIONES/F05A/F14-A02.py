import csv, math
from pathlib import Path

ruta = Path("repetidas.csv")
ruta.write_text("id,nota\n1,8\n1,8\n2,6\n2,7\n3,\n", encoding="utf-8")
aceptadas = {}
cuentas = {"duplicado exacto": 0, "conflicto": 0, "invalida": 0}
with ruta.open(encoding="utf-8", newline="") as archivo:
    for fila in csv.DictReader(archivo):
        try:
            nota = float(fila["nota"])
        except (ValueError, TypeError):
            cuentas["invalida"] += 1
            continue
        if not fila["id"].strip() or not math.isfinite(nota) or not 0 <= nota <= 10:
            cuentas["invalida"] += 1
            continue
        clave = fila["id"].strip()
        if clave not in aceptadas:
            aceptadas[clave] = nota
        elif aceptadas[clave] == nota:
            cuentas["duplicado exacto"] += 1
        else:
            cuentas["conflicto"] += 1
print("Aceptadas:", sorted(aceptadas.items()))
print("Clasificacion:", cuentas)
assert len(aceptadas) + sum(cuentas.values()) == 5
assert aceptadas == {"1": 8.0, "2": 6.0}
