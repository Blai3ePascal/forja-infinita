import csv
from collections import defaultdict
from pathlib import Path

entrada, salida = Path("entrada.csv"), Path("resumen.csv")
with entrada.open("w", encoding="utf-8", newline="") as archivo:
    w = csv.writer(archivo)
    w.writerow(["grupo", "nota"])
    w.writerows([("Azul, turno 1", 8), ("Verde", 6), ("Azul, turno 1", 4)])
por_grupo = defaultdict(list)
with entrada.open(encoding="utf-8", newline="") as archivo:
    for fila in csv.DictReader(archivo):
        por_grupo[fila["grupo"]].append(float(fila["nota"]))
with salida.open("w", encoding="utf-8", newline="") as archivo:
    w = csv.DictWriter(archivo, fieldnames=["grupo", "n", "media"])
    w.writeheader()
    for grupo, notas in sorted(por_grupo.items()):
        w.writerow(
            {"grupo": grupo, "n": len(notas), "media": f"{sum(notas)/len(notas):.2f}"}
        )
with salida.open(encoding="utf-8", newline="") as archivo:
    lector = csv.DictReader(archivo)
    assert lector.fieldnames == ["grupo", "n", "media"]
    recuperadas = list(lector)
print(recuperadas)
assert recuperadas == [
    {"grupo": "Azul, turno 1", "n": "2", "media": "6.00"},
    {"grupo": "Verde", "n": "1", "media": "6.00"},
]
print("Archivo reabierto: resumen.csv")
