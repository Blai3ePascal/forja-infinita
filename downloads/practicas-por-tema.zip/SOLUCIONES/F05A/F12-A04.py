import pandas as pd
import math


def forma(valores):
    s = pd.Series(valores, dtype=float)
    if len(s) < 4 or not all(math.isfinite(x) for x in s) or s.var(ddof=0) == 0:
        return None
    return round(float(s.skew()), 6), round(float(s.kurt()), 6)


print("Simetrica:", forma([-2, -1, 0, 1, 2]))
print("Cola derecha:", forma([1, 1, 1, 1, 10]))
print("Constante:", forma([3, 3, 3, 3]))
assert forma([-2, -1, 0, 1, 2])[0] == 0
assert forma([1, 1, 1, 1, 10])[0] > 0
assert forma([3, 3, 3, 3]) is None
