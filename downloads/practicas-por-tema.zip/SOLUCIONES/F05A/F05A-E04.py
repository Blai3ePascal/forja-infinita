import pandas as pd
datos = pd.DataFrame({"ventas": [8, None, 12, None]})
print(int(datos["ventas"].isna().sum()))
print(datos["ventas"].mean())
print(datos["ventas"].fillna(0).mean())
