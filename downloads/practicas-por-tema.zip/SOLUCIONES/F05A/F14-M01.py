import csv
from pathlib import Path

ruta = Path("referencia.csv")
with ruta.open("w", encoding="utf-8", newline="") as archivo:
    escritor = csv.writer(archivo)
    escritor.writerow(["grupo", "nota"])
    escritor.writerow(["Azul, turno 1", "8"])
with ruta.open(encoding="utf-8", newline="") as archivo:
    filas = list(csv.DictReader(archivo))
print(filas)
