def media(valores):
    if not valores:
        return None
    return sum(valores) / len(valores)


for caso in [[], [5], [4, 8]]:
    print(media(caso))
