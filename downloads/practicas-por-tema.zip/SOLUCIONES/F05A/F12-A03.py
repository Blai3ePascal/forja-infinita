from collections import Counter
import pandas as pd


def modas(valores):
    if not valores:
        return [], 0
    frecuencias = Counter(valores)
    maxima = max(frecuencias.values())
    return sorted(x for x, n in frecuencias.items() if n == maxima), maxima


for valores in [[1, 1, 2, 2, 3], [1, 2, 3], []]:
    resultado, frecuencia = modas(valores)
    print(valores, "->", resultado, "frecuencia:", frecuencia)
    if frecuencia == 1:
        print("Sin moda distinguida: todas las frecuencias son uno")
    if valores:
        assert resultado == pd.Series(valores).mode().tolist()
