from PIL import Image
im = Image.open("insignia.png")
im.convert("L").save("resultado.png")
print("Guardada")
