Usa Pillow sobre insignia.png. Abrir la insignia. El archivo de entrada mide 8 por 6 píxeles y su esquina (0,0) es RGB (40,120,180). La imagen tiene colores distintos según la posición; esto permite distinguir un giro de un cambio de tamaño.

Usa Pillow sobre insignia.png. Abrir la insignia. El archivo de entrada mide 8 por 6 píxeles y su esquina (0,0) es RGB (40,120,180).

### Leer la propuesta

- `from PIL import Image`: Image proporciona las operaciones de Pillow; PIL es el nombre del paquete que se importa.
- `im = Image.open("insignia.png")`: Abre la imagen de práctica; todavía no modifica ni guarda una copia.
- `print(im.size)`: Presenta el resultado para observarlo y compararlo. El salto de línea separa los resultados.

### Prueba otra decisión

En Laboratorio libre cambia un dato o un tamaño y compara la salida. Vuelve al objetivo para comprobar los casos de la misión. Si aparecen dos bucles, identifica qué recorre cada uno; si aparece una dirección, distingue el puntero de su destino.