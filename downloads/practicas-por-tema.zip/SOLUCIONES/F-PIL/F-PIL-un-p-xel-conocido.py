from PIL import Image
im = Image.open("insignia.png")
print(im.getpixel((0, 0)))
