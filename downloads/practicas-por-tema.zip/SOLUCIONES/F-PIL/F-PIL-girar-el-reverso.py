from PIL import Image
im = Image.open("insignia.png")
im.rotate(90, expand=True).save("resultado.png")
print("Guardada")
