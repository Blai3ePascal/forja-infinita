from PIL import Image
im = Image.open("insignia.png")
print(im.size)
