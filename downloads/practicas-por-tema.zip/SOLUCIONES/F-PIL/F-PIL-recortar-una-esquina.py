from PIL import Image
im = Image.open("insignia.png")
im.crop((0, 0, 4, 3)).save("resultado.png")
print("Guardada")
