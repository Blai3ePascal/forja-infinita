from PIL import Image
im = Image.open("insignia.png")
im.resize((16, 12)).save("resultado.png")
print("Guardada")
