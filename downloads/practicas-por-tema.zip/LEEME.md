# Banco docente revisado

Pascal & Sara · 20 de octubre de 2026

Sube los cuadernos a Google Colab con Archivo → Subir cuaderno. Cada bloque tiene versión de trabajo y versión con propuestas explicadas. Los ejercicios sin resolver pueden contener huecos o fallos deliberados; no se consideran programas terminados.

En C, usa un entorno Linux de Colab con gcc. Las celdas escriben main.c y compilan los archivos auxiliares de esa misión. Los códigos de salida distintos de cero se muestran para analizar también casos de error.

En Python, los programas interactivos solicitan su entrada; el enunciado muestra los valores de referencia. En SQL se crea una conexión SQLite independiente por misión.

La web aplica comprobaciones adicionales de resultados y requisitos. Estos cuadernos son material de estudio y no un sistema de calificación. Los casos y propuestas del juego son la referencia revisada.

Conserva también los paquetes originales: este banco complementa sus diapositivas y calendario, no cambia su evaluación oficial.
