# Biblioteca de cuadernos

Pascal & Sara · Edición 1.1

Abre una versión **Trabajo** para practicar. La versión **Soluciones** es una referencia, no un requisito para empezar.

| Bloque | Trabajo | Propuestas explicadas |
|---|---|---|
| La chispa inicial | [INICIO_Trabajo](INICIO_Trabajo.ipynb) | [INICIO_Soluciones](INICIO_Soluciones.ipynb) |
| Entorno Python y primeros resultados | [F01_Trabajo](F01_Trabajo.ipynb) | [F01_Soluciones](F01_Soluciones.ipynb) |
| Computador y representación de datos | [F02_Trabajo](F02_Trabajo.ipynb) | [F02_Soluciones](F02_Soluciones.ipynb) |
| Algoritmos, trazas y búsqueda | [F03_Trabajo](F03_Trabajo.ipynb) | [F03_Soluciones](F03_Soluciones.ipynb) |
| Variables, decisiones, funciones y objetos | [F04_Trabajo](F04_Trabajo.ipynb) | [F04_Soluciones](F04_Soluciones.ipynb) |
| Tablas, datos ausentes y estadística | [F05A_Trabajo](F05A_Trabajo.ipynb) | [F05A_Soluciones](F05A_Soluciones.ipynb) |
| Gráficos e interpretación de datos | [F05B_Trabajo](F05B_Trabajo.ipynb) | [F05B_Soluciones](F05B_Soluciones.ipynb) |
| Integración de lectura, validación e informe | [F06_Trabajo](F06_Trabajo.ipynb) | [F06_Soluciones](F06_Soluciones.ipynb) |
| Bases de datos, tablas y claves | [F07_Trabajo](F07_Trabajo.ipynb) | [F07_Soluciones](F07_Soluciones.ipynb) |
| Modelo E/R y transformación a tablas | [F08_Trabajo](F08_Trabajo.ipynb) | [F08_Soluciones](F08_Soluciones.ipynb) |
| SQL para consultar y modificar | [F09_Trabajo](F09_Trabajo.ipynb) | [F09_Soluciones](F09_Soluciones.ipynb) |
| Colecciones: posiciones, cambios y copias | [F10_Trabajo](F10_Trabajo.ipynb) | [F10_Soluciones](F10_Soluciones.ipynb) |
| Ordenar, conservar datos y contar trabajo | [F11_Trabajo](F11_Trabajo.ipynb) | [F11_Soluciones](F11_Soluciones.ipynb) |
| Estadística: cálculo, convención e interpretación | [F12_Trabajo](F12_Trabajo.ipynb) | [F12_Soluciones](F12_Soluciones.ipynb) |
| Gráficos que responden a una pregunta | [F13_Trabajo](F13_Trabajo.ipynb) | [F13_Soluciones](F13_Soluciones.ipynb) |
| Archivos CSV: contrato, limpieza y persistencia | [F14_Trabajo](F14_Trabajo.ipynb) | [F14_Soluciones](F14_Soluciones.ipynb) |
| SQLite: datos persistentes y cambios comprobables | [F15_Trabajo](F15_Trabajo.ipynb) | [F15_Soluciones](F15_Soluciones.ipynb) |
| Computador, memoria, rendimiento y bytecode | [F16_Trabajo](F16_Trabajo.ipynb) | [F16_Soluciones](F16_Soluciones.ipynb) |
| Interacción, accesibilidad y comunicación de resultados | [F17_Trabajo](F17_Trabajo.ipynb) | [F17_Soluciones](F17_Soluciones.ipynb) |
| La jugada antes del código | [F-MET_Trabajo](F-MET_Trabajo.ipynb) | [F-MET_Soluciones](F-MET_Soluciones.ipynb) |
| Taller de imágenes con Pillow | [F-PIL_Trabajo](F-PIL_Trabajo.ipynb) | [F-PIL_Soluciones](F-PIL_Soluciones.ipynb) |
| El mercado relacional | [SQL_Trabajo](SQL_Trabajo.ipynb) | [SQL_Soluciones](SQL_Soluciones.ipynb) |