# Biblioteca de cuadernos

Pascal & Sara · Edición 1.2

Abre una versión **Trabajo** para practicar. La versión **Soluciones** es una referencia, no un requisito para empezar.

| Bloque | Trabajo | Propuestas explicadas |
|---|---|---|
| Entorno Python y primeros resultados | [F01_Trabajo](F01_Trabajo.ipynb) | [F01_Soluciones](F01_Soluciones.ipynb) |
| Computador y representación de datos | [F02_Trabajo](F02_Trabajo.ipynb) | [F02_Soluciones](F02_Soluciones.ipynb) |
| Algoritmos, trazas y búsqueda | [F03_Trabajo](F03_Trabajo.ipynb) | [F03_Soluciones](F03_Soluciones.ipynb) |
| Variables, decisiones, funciones y objetos | [F04_Trabajo](F04_Trabajo.ipynb) | [F04_Soluciones](F04_Soluciones.ipynb) |
| Tablas, datos ausentes y estadística | [F05A_Trabajo](F05A_Trabajo.ipynb) | [F05A_Soluciones](F05A_Soluciones.ipynb) |
| Gráficos e interpretación de datos | [F05B_Trabajo](F05B_Trabajo.ipynb) | [F05B_Soluciones](F05B_Soluciones.ipynb) |
| Bases de datos, tablas y claves | [F07_Trabajo](F07_Trabajo.ipynb) | [F07_Soluciones](F07_Soluciones.ipynb) |
| Modelo E/R y transformación a tablas | [F08_Trabajo](F08_Trabajo.ipynb) | [F08_Soluciones](F08_Soluciones.ipynb) |
| SQL para consultar y modificar | [F09_Trabajo](F09_Trabajo.ipynb) | [F09_Soluciones](F09_Soluciones.ipynb) |