import sqlite3
with sqlite3.connect(":memory:") as db:
    db.execute("CREATE TABLE cartas(id INTEGER PRIMARY KEY,nombre TEXT)")
    db.execute("INSERT INTO cartas VALUES(?,?)",(1,"Faro"))
    print(db.execute("SELECT nombre FROM cartas").fetchall())
