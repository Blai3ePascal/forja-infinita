# Taller

Pascal y Sara Ignacio-Cerrato Ph.D.

python archivo.py ejecuta el proyecto sin dependencias externas. SQLite pertenece a la biblioteca estándar de Python. Para los temas de imágenes y gráficos utiliza el entorno probado que acompaña a la web; en un entorno local instala versiones compatibles de requirements.txt.
Git: git init; git add archivo.py requirements.txt LEEME.md; git commit -m "Primera carta". Modifica la consulta, consulta git diff y ejecuta de nuevo.
